//
// APBMA road-side unit application  (Veins 5.x, DemoBaseApplLayer)        rsu[0], rsu[1], ...
//
// * broadcasts a HELLO (RSU index and position) so that vehicles can discover it,
// * answers M3 with M4 and M5 with M6 (unicast to the vehicle that sent the request),
// * models the RSU crypto engine as a FIFO queue, so the RSU delay grows with the load.
// See TraCIDemo11p.h for the message formats.
//
#pragma once

#include <cstdint>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include "veins/base/modules/BaseMobility.h"
#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"

#ifndef VEINS_APBMA_COMMON_DEFINED
#define VEINS_APBMA_COMMON_DEFINED
namespace veins {

/** Cryptographic operations executed by one protocol step (shared by vehicle and RSU). */
struct ApbmaOps {
    long hash = 0;     // h(.)              SHA-256
    long mac = 0;      // H_k(.)            HMAC-SHA-256
    long xr = 0;       // bitwise XOR
    long puf = 0;      // PUF evaluation    R = P(C)
    long rnd = 0;      // random nonce / vector
    long bikeEnc = 0;  // BIKE encapsulation
    long bikeDec = 0;  // BIKE decapsulation (BGF decoder + re-encryption check)
    ApbmaOps& operator+=(const ApbmaOps& o)
    {
        hash += o.hash; mac += o.mac; xr += o.xr; puf += o.puf;
        rnd += o.rnd; bikeEnc += o.bikeEnc; bikeDec += o.bikeDec;
        return *this;
    }
};

/** Running statistic (count, sum, sum of squares, min, max); recorded as scalars. */
struct ApbmaAcc {
    long n = 0;
    double sum = 0, sqr = 0, mn = 1e300, mx = -1e300;
    void add(double x)
    {
        n++; sum += x; sqr += x * x;
        if (x < mn) mn = x;
        if (x > mx) mx = x;
    }
};

/**
 * Seconds (double) -> simtime_t.
 * NEVER write SimTime(x, SIMTIME_S) with a double x: in OMNeT++ 6.0 the only two-argument constructor takes
 * an int64_t, so the value is silently truncated to whole seconds (0.35 s -> 0 s, 1.5 s -> 1 s).
 */
inline simtime_t apbmaSecs(double s)
{
    return SimTime(s);
}

/** Message types carried in TraCIDemo11pMessage::demoData.  M3..M6 are the protocol, HELLO is RSU discovery. */
enum { APBMA_T_M3 = 0, APBMA_T_M4 = 1, APBMA_T_M5 = 2, APBMA_T_M6 = 3, APBMA_T_HELLO = 4, APBMA_T_BG = 5, APBMA_T_COUNT = 6 };
inline const char* apbmaTypeName(int t)
{
    static const char* const n[APBMA_T_COUNT] = {"M3", "M4", "M5", "M6", "HELLO", "BG"};
    return (t >= 0 && t < APBMA_T_COUNT) ? n[t] : "?";
}

/**
 * Wire format (demoData):
 *   M3..M6 :  APBMA|<type>|<session>|<txTimeRaw>
 *   HELLO  :  APBMA|HELLO|<rsuIndex>|<txTimeRaw>|<x>|<y>
 *   BG     :  APBMA|BG|<nodeId>|<txTimeRaw>            (optional background traffic)
 * txTimeRaw is the simulation time (raw ticks) at which the frame is handed to the MAC.
 */
struct ApbmaMsg {
    int type = -1;
    std::string session;      // session id (M3..M6) or RSU index (HELLO)
    int64_t txRaw = 0;
    bool hasPos = false;
    double x = 0, y = 0;
};

inline bool apbmaParse(const char* text, ApbmaMsg& out)
{
    std::vector<std::string> f;
    std::istringstream in(text ? text : "");
    std::string part;
    while (std::getline(in, part, '|'))
        f.push_back(part);
    if (f.size() < 4 || f[0] != "APBMA" || f[2].empty()) return false;
    out.type = -1;
    for (int i = 0; i < APBMA_T_COUNT; i++)
        if (f[1] == apbmaTypeName(i)) out.type = i;
    if (out.type < 0) return false;
    try {
        out.txRaw = std::stoll(f[3]);
        out.hasPos = false;
        if (out.type == APBMA_T_HELLO) {
            if (f.size() != 6) return false;
            out.x = std::stod(f[4]);
            out.y = std::stod(f[5]);
            out.hasPos = true;
        }
        else if (f.size() != 4) {
            return false;
        }
    }
    catch (...) {
        return false;
    }
    out.session = f[2];
    return true;
}


/**
 * Operation counts of one protocol step from a string such as "mac=2,xor=1,puf=1".
 * Keys: hash mac xor puf rnd bikeEnc bikeDec. Returns false for an unknown key or a bad number.
 */
inline bool apbmaParseOps(const std::string& spec, ApbmaOps& out)
{
    ApbmaOps o;
    std::istringstream in(spec);
    std::string item;
    while (std::getline(in, item, ',')) {
        std::string clean;
        for (char c : item)
            if (c != ' ' && c != '\t') clean += c;
        if (clean.empty()) continue;
        const size_t eq = clean.find('=');
        if (eq == std::string::npos) return false;
        const std::string k = clean.substr(0, eq);
        long v = 0;
        try {
            v = std::stol(clean.substr(eq + 1));
        }
        catch (...) {
            return false;
        }
        if (v < 0) return false;
        if (k == "hash") o.hash = v;
        else if (k == "mac") o.mac = v;
        else if (k == "xor") o.xr = v;
        else if (k == "puf") o.puf = v;
        else if (k == "rnd") o.rnd = v;
        else if (k == "bikeEnc") o.bikeEnc = v;
        else if (k == "bikeDec") o.bikeDec = v;
        else return false;
    }
    out = o;
    return true;
}

} // namespace veins
#endif

namespace veins {

class VEINS_API TraCIDemoRSU11p : public DemoBaseApplLayer {
public:
    ~TraCIDemoRSU11p() override;
    void initialize(int stage) override;
    void finish() override;

protected:
    static const int APBMA_TYPES = 4; // index 0..3 = M3, M4, M5, M6

    struct Session {
        LAddress::L2Type vehicle = -1;
        int phase = 1;                // 1 = M4 sent (wait M5)
        simtime_t created;
    };

    // ---- configuration (omnetpp.ini parameters, defaults in the code) ----
    double cfgHelloInterval = 0.35;   // HELLO period [s]
    int helloBytes = 40;
    double cfgSessionTtl = 5.0;       // forget half-open sessions after [s]
    bool cfgSerialCpu = true;         // one crypto engine: requests queue up
    bool cfgVerbose = false;
    int payloadBytes[APBMA_TYPES] = {51, 80, 48, 1621};
    // crypto time model of the RSU [s per operation]  (ASSUMED values: replace by measurements)
    double tHash = 5e-6, tMac = 10e-6, tXor = 0.5e-6, tPuf = 500e-6, tRnd = 5e-6;
    double tBikeEnc = 250e-6, tBikeDec = 1.5e-3;
    bool costProfileIsDefault = true;
    // operations of the two RSU steps (override with apbmaOpsRsuM3 / apbmaOpsRsuM5)
    ApbmaOps opsM3, opsM5;

    // ---- state ----
    int rsuIndex = -1;                                  // rsu[rsuIndex]
    std::map<std::string, Session> apbmaSessions;       // sessionId -> state
    std::set<LAddress::L2Type> seenVehicles, acceptedVehicles;
    simtime_t cpuFreeAt;                                // end of the work already queued on the crypto engine
    cMessage* cleanupEvt = nullptr;
    cMessage* helloEvt = nullptr;

    // ---- counters ----
    long txPkts[APBMA_TYPES] = {}, txBytes[APBMA_TYPES] = {}, txBits[APBMA_TYPES] = {};
    long rxPkts[APBMA_TYPES] = {}, rxBytes[APBMA_TYPES] = {};
    long helloTx = 0;
    long bgRx = 0;                    // background frames of the vehicles heard by this RSU
    long sessionsOpened = 0, sessionsAccepted = 0, sessionsExpired = 0;
    long duplicateRx = 0, staleRx = 0, wrongDestRx = 0;
    double rxDelaySum = 0, cryptoSeconds = 0, queueWaitSum = 0;
    ApbmaOps totalOps;
    ApbmaAcc e2eAcc[APBMA_TYPES], queueWaitAcc, serviceAcc;

    // ---- helpers ----
    double apbmaPar(const char* name, double dflt);
    std::string apbmaStr(const char* name);
    void loadOps(const char* name, ApbmaOps& dst);
    double opSeconds(const ApbmaOps& ops) const;
    double reserveCpu(const ApbmaOps& ops);             // returns the delay until the result is ready
    void sendHello();
    void sendApbma(int type, const std::string& session, LAddress::L2Type recipient, double delaySeconds);

    // ---- Veins callbacks ----
    void onWSM(BaseFrame1609_4* wsm) override;
    void onWSA(DemoServiceAdvertisment* wsa) override;
    void handleSelfMsg(cMessage* msg) override;
};

} // namespace veins
