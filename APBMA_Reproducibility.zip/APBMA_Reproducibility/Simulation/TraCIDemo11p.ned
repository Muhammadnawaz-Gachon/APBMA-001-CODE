//
// Copyright (C) 2006-2011 Christoph Sommer <christoph.sommer@uibk.ac.at>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

package org.car2x.veins.modules.application.traci;

import org.car2x.veins.modules.application.ieee80211p.DemoBaseApplLayer;

//
// APBMA vehicle application (node[n]).  All apbma* parameters are optional: the C++ code uses the same defaults.
//
simple TraCIDemo11p extends DemoBaseApplLayer
{
    parameters:
        @class(veins::TraCIDemo11p);
        @display("i=block/app2");

        // --- handshake control ---
        double apbmaHelloLifetime @unit(s) = default(1s);    // a HELLO older than this: RSU not in range
        double apbmaStartJitter @unit(s) = default(0.05s);   // spreads M3 of vehicles hearing the same HELLO
        double apbmaTimeout @unit(s) = default(0.5s);        // M3 start -> M6 verified, else the attempt fails
        double apbmaRetryDelay @unit(s) = default(0.5s);
        int apbmaMaxRetries = default(3);                    // retries in one burst
        double apbmaCooldown @unit(s) = default(2s);         // pause after a failed burst, then try again
        double apbmaMaxAuthDist @unit(m) = default(300m);    // start M3 only below this distance (0 = no limit)
        int apbmaRsuSelect = default(-1);                    // -1 = every RSU, k = only rsu[k] (1-RSU vs 2-RSU comparison)
        double apbmaBgInterval @unit(s) = default(0s);       // background broadcast traffic per vehicle (0 = off)
        int apbmaBgBytes = default(200);                     // payload of a background frame
        double apbmaCoverageGap @unit(s) = default(3s);      // silence longer than this = new coverage episode
        double apbmaReauthInterval @unit(s) = default(0s);   // 0 = authenticate once per RSU
        double apbmaDiagRange @unit(m) = default(300m);      // "in range" distance of the geometry diagnostics
        bool apbmaVerbose = default(false);

        // --- logical payload sizes [bytes] (vehicle and RSU must agree) ---
        int apbmaM3Bytes = default(51);                      // N1(16)+ID(3)+alpha(32)
        int apbmaM4Bytes = default(80);                      // N2(16)+omega(32)+Y(32)
        int apbmaM5Bytes = default(48);                      // j(32)+N3(16)
        int apbmaM6Bytes = default(1621);                    // N4(16)+T(1573)+tag(32), BIKE level 1

        // --- operations per step, e.g. "mac=2,xor=1,puf=1"  (keys: hash mac xor puf rnd bikeEnc bikeDec; "" = default)
        //     defaults: M3 "rnd=1,mac=1"   M4 "mac=2,xor=2,puf=1,hash=1,rnd=1"   M6 "bikeDec=1,mac=1"
        string apbmaOpsVehM3 = default("");
        string apbmaOpsVehM4 = default("");
        string apbmaOpsVehM6 = default("");

        // --- OBU crypto time model [s per operation]: ASSUMED values, replace by measurements ---
        double apbmaTimeHash @unit(s) = default(20us);
        double apbmaTimeMac @unit(s) = default(40us);
        double apbmaTimeXor @unit(s) = default(1us);
        double apbmaTimePuf @unit(s) = default(500us);
        double apbmaTimeRnd @unit(s) = default(20us);
        double apbmaTimeBikeEnc @unit(s) = default(800us);
        double apbmaTimeBikeDec @unit(s) = default(8ms);
}
