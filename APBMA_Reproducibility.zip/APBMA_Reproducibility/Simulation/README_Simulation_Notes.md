# Notes on this Simulation folder

## What is, and is not, included here

This folder contains only the files **authored for APBMA**:

- `APBMA.ini` — the complete, self-contained OMNeT++ configuration (`[General]` +
  `[Config APBMA]`). It does **not** `include` or `extend` any other `.ini` file.
- `TraCIDemo11p.{h,cc,ned}` — the vehicle application implementing the APBMA run-time
  protocol (messages M3-M6) on the vehicle side.
- `TraCIDemoRSU11p.{h,cc,ned}` — the matching RSU application.
- `analyze_apbma.py`, `suggest_rsu_positions.py` — helper scripts for post-processing results
  and placing RSUs on a given SUMO scenario.

### `RSUExampleScenario.ini` / `RSUExampleScenario.ned`

These two files were part of the original requested file list, but **they are not included in
this repository** and have not been authored here: `RSUExampleScenario` is the name of the
**stock example scenario distributed with Veins itself** (under
`veins/examples/veins/` in a standard Veins checkout), including its own network definition
(`.ned`) and default `omnetpp.ini`. APBMA.ini sets `network = RSUExampleScenario`, i.e. it
**reuses** that existing Veins example network rather than redefining it, and supplies its own
complete `[General]`/`[Config APBMA]` sections instead of including Veins' own `omnetpp.ini`.

To run the simulation you therefore need a working Veins installation (see
`../Documentation/Installation_and_Requirements.md`), which already provides
`RSUExampleScenario.ned` and the scenario's supporting files (`config.xml`, `antenna.xml`,
`erlangen.launchd.xml`, the SUMO network/route files for Erlangen). Copy `APBMA.ini` (and the
six `TraCIDemo*` files, compiled into the example) into that example's directory, next to those
Veins-provided files, before launching the simulation — see
`../Documentation/Simulation_Instructions.md` for the exact steps.

Per the reproducibility requirements for this package, no substitute or re-authored copy of
Veins' own `RSUExampleScenario.ned`/example `.ini` is fabricated here.

## RSU placement used for the published results

The published results place the two RSUs at the OMNeT++ coordinates below, valid for the
**stock Veins Erlangen** scenario (already set in `APBMA.ini`):

```
*.rsu[0].mobility.x = 2462   *.rsu[0].mobility.y = 1912
*.rsu[1].mobility.x = 1862   *.rsu[1].mobility.y = 1812
```

If you run a different SUMO scenario, these coordinates will very likely put the RSUs off the
routes vehicles actually drive; use `suggest_rsu_positions.py <your .sumo.cfg>` to compute
positions for your own scenario instead of reusing the numbers above.
