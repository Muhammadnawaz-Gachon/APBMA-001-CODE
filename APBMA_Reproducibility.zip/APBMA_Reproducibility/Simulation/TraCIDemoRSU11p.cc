#include "veins/modules/application/traci/TraCIDemoRSU11p.h"
#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"

#include <algorithm>
#include <cmath>
#include <string>

using namespace veins;
Define_Module(veins::TraCIDemoRSU11p);

namespace {

/** Records an accumulator as plain scalars: <name>_count/_sum/_sqr/_min/_max/_mean. */
template <class Rec>
void recAcc(Rec&& rec, const std::string& name, const ApbmaAcc& a)
{
    rec(name + "_count", static_cast<double>(a.n));
    if (a.n > 0) {
        rec(name + "_sum", a.sum);
        rec(name + "_sqr", a.sqr);
        rec(name + "_min", a.mn);
        rec(name + "_max", a.mx);
        rec(name + "_mean", a.sum / static_cast<double>(a.n));
    }
}

} // namespace

// ---------------------------------------------------------------------------------------------
// lifecycle
// ---------------------------------------------------------------------------------------------
TraCIDemoRSU11p::~TraCIDemoRSU11p()
{
    cancelAndDelete(cleanupEvt);
    cancelAndDelete(helloEvt);
}

double TraCIDemoRSU11p::apbmaPar(const char* name, double dflt)
{
    // Parameters are optional (the NED file may not declare them). OMNeT++ 6 does not convert between
    // parameter types, so read the value according to its declared type.
    if (!hasPar(name)) return dflt;
    const cPar& p = par(name);
    switch (p.getType()) {
    case cPar::DOUBLE: return p.doubleValue();
    case cPar::INT: return static_cast<double>(p.intValue());
    case cPar::BOOL: return p.boolValue() ? 1.0 : 0.0;
    default: return dflt;
    }
}

std::string TraCIDemoRSU11p::apbmaStr(const char* name)
{
    if (!hasPar(name)) return "";
    const cPar& p = par(name);
    return p.getType() == cPar::STRING ? std::string(p.stringValue()) : std::string();
}

void TraCIDemoRSU11p::loadOps(const char* name, ApbmaOps& dst)
{
    const std::string spec = apbmaStr(name);
    if (spec.empty()) return; // keep the built-in default
    ApbmaOps o;
    if (!apbmaParseOps(spec, o))
        throw cRuntimeError("APBMA: bad operation list '%s' for %s (use e.g. \"mac=2,bikeEnc=1\"; keys: hash mac xor puf rnd bikeEnc bikeDec)", spec.c_str(), name);
    dst = o;
}

void TraCIDemoRSU11p::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);
    if (stage == 1) {
        // fail fast if the seconds -> simtime_t conversion ever truncates (see apbmaSecs())
        if (std::fabs(apbmaSecs(0.35).dbl() - 0.35) > 1e-9) throw cRuntimeError("APBMA: seconds->simtime_t conversion is broken");

        rsuIndex = getParentModule()->getIndex();
        cfgHelloInterval = apbmaPar("apbmaHelloInterval", cfgHelloInterval);
        if (cfgHelloInterval < 0.001) throw cRuntimeError("apbmaHelloInterval must be at least 1 ms");
        helloBytes = static_cast<int>(apbmaPar("apbmaHelloBytes", helloBytes));
        payloadBytes[APBMA_T_M3] = static_cast<int>(apbmaPar("apbmaM3Bytes", payloadBytes[APBMA_T_M3]));
        payloadBytes[APBMA_T_M4] = static_cast<int>(apbmaPar("apbmaM4Bytes", payloadBytes[APBMA_T_M4]));
        payloadBytes[APBMA_T_M5] = static_cast<int>(apbmaPar("apbmaM5Bytes", payloadBytes[APBMA_T_M5]));
        payloadBytes[APBMA_T_M6] = static_cast<int>(apbmaPar("apbmaM6Bytes", payloadBytes[APBMA_T_M6]));
        cfgSessionTtl = apbmaPar("apbmaSessionTtl", cfgSessionTtl);
        cfgSerialCpu = apbmaPar("apbmaRsuSerialCpu", 1) != 0;
        cfgVerbose = apbmaPar("apbmaVerbose", 0) != 0;
        tHash = apbmaPar("apbmaTimeHash", tHash);
        tMac = apbmaPar("apbmaTimeMac", tMac);
        tXor = apbmaPar("apbmaTimeXor", tXor);
        tPuf = apbmaPar("apbmaTimePuf", tPuf);
        tRnd = apbmaPar("apbmaTimeRnd", tRnd);
        tBikeEnc = apbmaPar("apbmaTimeBikeEnc", tBikeEnc);
        tBikeDec = apbmaPar("apbmaTimeBikeDec", tBikeDec);
        // flag results that still use the built-in ASSUMED crypto timing profile (replace by measured values)
        auto near = [](double a, double b) { return std::fabs(a - b) <= 1e-9 * std::fabs(b); };
        costProfileIsDefault = near(tHash, 5e-6) && near(tMac, 10e-6) && near(tPuf, 500e-6) &&
                               near(tBikeEnc, 250e-6) && near(tBikeDec, 1.5e-3);

        // operations per protocol step (defaults = the hardened APBMA; override with apbmaOps* strings)
        opsM3.mac = 2; opsM3.hash = 1; opsM3.xr = 1; opsM3.rnd = 1;   // verify alpha, beta, omega, N2, Y
        opsM5.mac = 2; opsM5.bikeEnc = 1; opsM5.rnd = 1;              // verify j, BIKE encaps, N4, tag
        loadOps("apbmaOpsRsuM3", opsM3);
        loadOps("apbmaOpsRsuM5", opsM5);

        cpuFreeAt = SimTime::ZERO;
        cleanupEvt = new cMessage("APBMA_CLEANUP");
        scheduleAt(simTime() + apbmaSecs(1.0), cleanupEvt);
        helloEvt = new cMessage("APBMA_HELLO_TIMER");
        // random phase, so that the HELLOs of different RSUs do not collide
        scheduleAt(simTime() + apbmaSecs(uniform(0.02, 0.12)), helloEvt);
    }
}

// ---------------------------------------------------------------------------------------------
// crypto time model and RSU crypto engine
// ---------------------------------------------------------------------------------------------
double TraCIDemoRSU11p::opSeconds(const ApbmaOps& o) const
{
    return o.hash * tHash + o.mac * tMac + o.xr * tXor + o.puf * tPuf + o.rnd * tRnd + o.bikeEnc * tBikeEnc +
           o.bikeDec * tBikeDec;
}

double TraCIDemoRSU11p::reserveCpu(const ApbmaOps& ops)
{
    const double service = opSeconds(ops);
    double wait = 0;
    if (cfgSerialCpu) {
        // FIFO crypto engine: a request waits until the previously queued work is finished
        const simtime_t start = std::max(simTime(), cpuFreeAt);
        wait = (start - simTime()).dbl();
        cpuFreeAt = start + apbmaSecs(service);
    }
    totalOps += ops;
    cryptoSeconds += service;
    queueWaitSum += wait;
    queueWaitAcc.add(wait);
    serviceAcc.add(service);
    return wait + service;
}

// ---------------------------------------------------------------------------------------------
// protocol
// ---------------------------------------------------------------------------------------------
void TraCIDemoRSU11p::sendHello()
{
    auto* pkt = new TraCIDemo11pMessage();
    populateWSM(pkt, LAddress::L2BROADCAST());
    pkt->setSenderAddress(myId);
    std::ostringstream data;
    data << "APBMA|HELLO|" << rsuIndex << "|" << simTime().raw() << "|" << curPosition.x << "|" << curPosition.y;
    pkt->setDemoData(data.str().c_str());
    pkt->setBitLength(headerLength + 8 * helloBytes);
    sendDown(pkt);
    helloTx++;
}

void TraCIDemoRSU11p::sendApbma(int type, const std::string& session, LAddress::L2Type recipient,
                                double delaySeconds)
{
    auto* pkt = new TraCIDemo11pMessage();
    populateWSM(pkt, recipient);
    pkt->setSenderAddress(myId); // the vehicle uses it to identify (and address) its RSU

    const simtime_t delay = apbmaSecs(delaySeconds);
    const simtime_t txTime = simTime() + delay; // instant at which the frame reaches the MAC
    std::ostringstream data;
    data << "APBMA|" << apbmaTypeName(type) << "|" << session << "|" << txTime.raw();
    pkt->setDemoData(data.str().c_str());
    pkt->setBitLength(headerLength + 8 * payloadBytes[type]);

    txPkts[type]++;
    txBytes[type] += payloadBytes[type];
    txBits[type] += pkt->getBitLength();
    sendDelayedDown(pkt, delay);
}

void TraCIDemoRSU11p::onWSM(BaseFrame1609_4* frame)
{
    auto* pkt = dynamic_cast<TraCIDemo11pMessage*>(frame);
    if (!pkt) return;
    ApbmaMsg m;
    if (!apbmaParse(pkt->getDemoData(), m)) return;
    if (m.type == APBMA_T_BG) {
        bgRx++; // background frame of a vehicle: only load on the channel
        return;
    }
    if (m.type != APBMA_T_M3 && m.type != APBMA_T_M5) return; // HELLO / M4 / M6 are RSU -> vehicle
    if (pkt->getRecipientAddress() != myId) {
        wrongDestRx++;
        return;
    }

    const LAddress::L2Type vehicle = pkt->getSenderAddress();
    SimTime tx;
    tx.setRaw(m.txRaw);
    const double d = (simTime() - tx).dbl();
    rxPkts[m.type]++;
    rxBytes[m.type] += payloadBytes[m.type];
    rxDelaySum += d;
    e2eAcc[m.type].add(d);

    auto it = apbmaSessions.find(m.session);

    if (m.type == APBMA_T_M3) {
        if (it != apbmaSessions.end()) {
            duplicateRx++;
            return;
        }
        Session s;
        s.vehicle = vehicle;
        s.phase = 1;
        s.created = simTime();
        apbmaSessions[m.session] = s;
        sessionsOpened++;
        seenVehicles.insert(vehicle);
        // M3 handling: verify alpha (MAC), beta = h(R), omega = C xor beta, N2 <- rnd, Y = H_beta(N1||N2||omega)
        sendApbma(APBMA_T_M4, m.session, vehicle, reserveCpu(opsM3));
    }
    else { // APBMA_T_M5
        if (it == apbmaSessions.end() || it->second.vehicle != vehicle || it->second.phase != 1) {
            staleRx++; // unknown / expired / replayed session
            return;
        }
        sessionsAccepted++;
        acceptedVehicles.insert(vehicle);
        // M5 handling: verify j (MAC); BIKE encapsulation (mu_R, e0/e1, T0, T1, K_S); N4 <- rnd; tag (MAC)
        sendApbma(APBMA_T_M6, m.session, vehicle, reserveCpu(opsM5));
        if (cfgVerbose) EV_INFO << "APBMA rsu[" << rsuIndex << "] accepted vehicle " << vehicle << "\n";
        apbmaSessions.erase(it); // session finished, bounded memory
    }
}

void TraCIDemoRSU11p::handleSelfMsg(cMessage* msg)
{
    if (msg == helloEvt) {
        sendHello();
        scheduleAt(simTime() + apbmaSecs(cfgHelloInterval), helloEvt);
    }
    else if (msg == cleanupEvt) {
        for (auto it = apbmaSessions.begin(); it != apbmaSessions.end();) {
            if ((simTime() - it->second.created).dbl() > cfgSessionTtl) {
                it = apbmaSessions.erase(it);
                sessionsExpired++;
            }
            else {
                ++it;
            }
        }
        scheduleAt(simTime() + apbmaSecs(1.0), cleanupEvt);
    }
    else {
        DemoBaseApplLayer::handleSelfMsg(msg);
    }
}

void TraCIDemoRSU11p::onWSA(DemoServiceAdvertisment* wsa)
{
    // APBMA baseline: CCH only, no channel switching
}

// ---------------------------------------------------------------------------------------------
// results (plain scalars only: usable from .sca files and from the IDE's CSV export)
// ---------------------------------------------------------------------------------------------
void TraCIDemoRSU11p::finish()
{
    auto rec = [this](const std::string& n, double v) { recordScalar(n.c_str(), v); };

    rec("APBMA_rsuIndex", rsuIndex);
    long totTx = 0, totRx = 0, totTxBytes = 0;
    for (int i = 0; i < APBMA_TYPES; i++) {
        totTx += txPkts[i];
        totRx += rxPkts[i];
        totTxBytes += txBytes[i];
        const std::string t = apbmaTypeName(i);
        rec("APBMA_tx_" + t + "_pkts", txPkts[i]);
        rec("APBMA_tx_" + t + "_bytes", txBytes[i]);
        rec("APBMA_tx_" + t + "_bits", txBits[i]);
        rec("APBMA_rx_" + t + "_pkts", rxPkts[i]);
        rec("APBMA_rx_" + t + "_bytes", rxBytes[i]);
        recAcc(rec, "APBMA_e2e_" + t + "_s", e2eAcc[i]);
    }
    // names of the original version are kept for existing post-processing
    rec("APBMA_txPackets", totTx);
    rec("APBMA_rxPackets", totRx);
    rec("APBMA_txPayloadBytes", totTxBytes);
    rec("APBMA_rxDelaySum_s", rxDelaySum);
    rec("APBMA_cryptoCost_s", cryptoSeconds);

    rec("APBMA_helloTx", helloTx);
    rec("APBMA_bgRx", bgRx);
    rec("APBMA_cfg_helloInterval_s", cfgHelloInterval);
    rec("APBMA_sessionsOpened", sessionsOpened);
    rec("APBMA_sessionsAccepted", sessionsAccepted);
    rec("APBMA_sessionsExpired", sessionsExpired);
    rec("APBMA_sessionsOpenAtEnd", static_cast<double>(apbmaSessions.size()));
    rec("APBMA_uniqueVehicles", static_cast<double>(seenVehicles.size()));
    rec("APBMA_uniqueVehiclesAccepted", static_cast<double>(acceptedVehicles.size()));
    rec("APBMA_staleRx", staleRx);
    rec("APBMA_duplicateRx", duplicateRx);
    rec("APBMA_wrongDestRx", wrongDestRx);
    rec("APBMA_queueWaitSum_s", queueWaitSum);

    rec("APBMA_ops_hash", totalOps.hash);
    rec("APBMA_ops_mac", totalOps.mac);
    rec("APBMA_ops_xor", totalOps.xr);
    rec("APBMA_ops_puf", totalOps.puf);
    rec("APBMA_ops_rnd", totalOps.rnd);
    rec("APBMA_ops_bikeEnc", totalOps.bikeEnc);
    rec("APBMA_ops_bikeDec", totalOps.bikeDec);
    rec("APBMA_costProfileIsDefault", costProfileIsDefault ? 1 : 0);

    recAcc(rec, "APBMA_queueWait_s", queueWaitAcc);
    recAcc(rec, "APBMA_service_s", serviceAcc);
    DemoBaseApplLayer::finish();
}
