//
// Copyright (C) 2006-2011 Christoph Sommer <christoph.sommer@uibk.ac.at>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

package org.car2x.veins.modules.application.traci;

import org.car2x.veins.modules.application.ieee80211p.DemoBaseApplLayer;

//
// APBMA road-side unit application (rsu[k]).  All apbma* parameters are optional: the C++ code uses the same defaults.
//
simple TraCIDemoRSU11p extends DemoBaseApplLayer
{
    parameters:
        @class(veins::TraCIDemoRSU11p);
        @display("i=block/app2");

        double apbmaHelloInterval @unit(s) = default(0.35s); // HELLO period (>= 1 ms)
        int apbmaHelloBytes = default(40);
        double apbmaSessionTtl @unit(s) = default(5s);       // drop half-open sessions after this time
        bool apbmaRsuSerialCpu = default(true);              // one crypto engine: requests queue up
        bool apbmaVerbose = default(false);

        // --- logical payload sizes [bytes] (must equal the vehicle's) ---
        int apbmaM3Bytes = default(51);
        int apbmaM4Bytes = default(80);
        int apbmaM5Bytes = default(48);
        int apbmaM6Bytes = default(1621);

        // --- operations per step, e.g. "mac=2,bikeEnc=1"  (keys: hash mac xor puf rnd bikeEnc bikeDec; "" = default)
        //     defaults: M3 "mac=2,hash=1,xor=1,rnd=1"   M5 "mac=2,bikeEnc=1,rnd=1"
        string apbmaOpsRsuM3 = default("");
        string apbmaOpsRsuM5 = default("");

        // --- RSU crypto time model [s per operation]: ASSUMED values, replace by measurements ---
        double apbmaTimeHash @unit(s) = default(5us);
        double apbmaTimeMac @unit(s) = default(10us);
        double apbmaTimeXor @unit(s) = default(0.5us);
        double apbmaTimePuf @unit(s) = default(500us);
        double apbmaTimeRnd @unit(s) = default(5us);
        double apbmaTimeBikeEnc @unit(s) = default(250us);
        double apbmaTimeBikeDec @unit(s) = default(1.5ms);
}
