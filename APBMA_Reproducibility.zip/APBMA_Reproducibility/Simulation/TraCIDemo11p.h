//
// APBMA vehicle application  (Veins 5.x, DemoBaseApplLayer)            node[n]  <->  rsu[0], rsu[1], ...
//
// Every RSU broadcasts a HELLO. A vehicle that hears an RSU runs the APBMA handshake with it:
//
//   M3  V   -> RSU : N1 || ID_V || alpha          unicast to the RSU that sent the HELLO
//   M4  RSU -> V   : N2 || omega || Y             unicast
//   M5  V   -> RSU : j || N3                      unicast
//   M6  RSU -> V   : N4 || T || tag               unicast (BIKE ciphertext)
//
// A vehicle that drives past several RSUs authenticates with each of them, one handshake at a time.
// All results are recorded as plain scalars (also usable from the OMNeT++ IDE / CSV export).
//
#pragma once

#include <cstdint>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "veins/base/modules/BaseMobility.h"
#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"

#ifndef VEINS_APBMA_COMMON_DEFINED
#define VEINS_APBMA_COMMON_DEFINED
namespace veins {

/** Cryptographic operations executed by one protocol step (shared by vehicle and RSU). */
struct ApbmaOps {
    long hash = 0;     // h(.)              SHA-256
    long mac = 0;      // H_k(.)            HMAC-SHA-256
    long xr = 0;       // bitwise XOR
    long puf = 0;      // PUF evaluation    R = P(C)
    long rnd = 0;      // random nonce / vector
    long bikeEnc = 0;  // BIKE encapsulation
    long bikeDec = 0;  // BIKE decapsulation (BGF decoder + re-encryption check)
    ApbmaOps& operator+=(const ApbmaOps& o)
    {
        hash += o.hash; mac += o.mac; xr += o.xr; puf += o.puf;
        rnd += o.rnd; bikeEnc += o.bikeEnc; bikeDec += o.bikeDec;
        return *this;
    }
};

/** Running statistic (count, sum, sum of squares, min, max); recorded as scalars. */
struct ApbmaAcc {
    long n = 0;
    double sum = 0, sqr = 0, mn = 1e300, mx = -1e300;
    void add(double x)
    {
        n++; sum += x; sqr += x * x;
        if (x < mn) mn = x;
        if (x > mx) mx = x;
    }
};

/**
 * Seconds (double) -> simtime_t.
 * NEVER write SimTime(x, SIMTIME_S) with a double x: in OMNeT++ 6.0 the only two-argument constructor takes
 * an int64_t, so the value is silently truncated to whole seconds (0.35 s -> 0 s, 1.5 s -> 1 s).
 */
inline simtime_t apbmaSecs(double s)
{
    return SimTime(s);
}

/** Message types carried in TraCIDemo11pMessage::demoData.  M3..M6 are the protocol, HELLO is RSU discovery. */
enum { APBMA_T_M3 = 0, APBMA_T_M4 = 1, APBMA_T_M5 = 2, APBMA_T_M6 = 3, APBMA_T_HELLO = 4, APBMA_T_BG = 5, APBMA_T_COUNT = 6 };
inline const char* apbmaTypeName(int t)
{
    static const char* const n[APBMA_T_COUNT] = {"M3", "M4", "M5", "M6", "HELLO", "BG"};
    return (t >= 0 && t < APBMA_T_COUNT) ? n[t] : "?";
}

/**
 * Wire format (demoData):
 *   M3..M6 :  APBMA|<type>|<session>|<txTimeRaw>
 *   HELLO  :  APBMA|HELLO|<rsuIndex>|<txTimeRaw>|<x>|<y>
 *   BG     :  APBMA|BG|<nodeId>|<txTimeRaw>            (optional background traffic)
 * txTimeRaw is the simulation time (raw ticks) at which the frame is handed to the MAC.
 */
struct ApbmaMsg {
    int type = -1;
    std::string session;      // session id (M3..M6) or RSU index (HELLO)
    int64_t txRaw = 0;
    bool hasPos = false;
    double x = 0, y = 0;
};

inline bool apbmaParse(const char* text, ApbmaMsg& out)
{
    std::vector<std::string> f;
    std::istringstream in(text ? text : "");
    std::string part;
    while (std::getline(in, part, '|'))
        f.push_back(part);
    if (f.size() < 4 || f[0] != "APBMA" || f[2].empty()) return false;
    out.type = -1;
    for (int i = 0; i < APBMA_T_COUNT; i++)
        if (f[1] == apbmaTypeName(i)) out.type = i;
    if (out.type < 0) return false;
    try {
        out.txRaw = std::stoll(f[3]);
        out.hasPos = false;
        if (out.type == APBMA_T_HELLO) {
            if (f.size() != 6) return false;
            out.x = std::stod(f[4]);
            out.y = std::stod(f[5]);
            out.hasPos = true;
        }
        else if (f.size() != 4) {
            return false;
        }
    }
    catch (...) {
        return false;
    }
    out.session = f[2];
    return true;
}


/**
 * Operation counts of one protocol step from a string such as "mac=2,xor=1,puf=1".
 * Keys: hash mac xor puf rnd bikeEnc bikeDec. Returns false for an unknown key or a bad number.
 */
inline bool apbmaParseOps(const std::string& spec, ApbmaOps& out)
{
    ApbmaOps o;
    std::istringstream in(spec);
    std::string item;
    while (std::getline(in, item, ',')) {
        std::string clean;
        for (char c : item)
            if (c != ' ' && c != '\t') clean += c;
        if (clean.empty()) continue;
        const size_t eq = clean.find('=');
        if (eq == std::string::npos) return false;
        const std::string k = clean.substr(0, eq);
        long v = 0;
        try {
            v = std::stol(clean.substr(eq + 1));
        }
        catch (...) {
            return false;
        }
        if (v < 0) return false;
        if (k == "hash") o.hash = v;
        else if (k == "mac") o.mac = v;
        else if (k == "xor") o.xr = v;
        else if (k == "puf") o.puf = v;
        else if (k == "rnd") o.rnd = v;
        else if (k == "bikeEnc") o.bikeEnc = v;
        else if (k == "bikeDec") o.bikeDec = v;
        else return false;
    }
    out = o;
    return true;
}

} // namespace veins
#endif

namespace veins {

class VEINS_API TraCIDemo11p : public DemoBaseApplLayer {
public:
    ~TraCIDemo11p() override;
    void initialize(int stage) override;
    void finish() override;

protected:
    static const int APBMA_TYPES = 4; // index 0..3 = M3, M4, M5, M6

    /** What this vehicle knows about one RSU (keyed by the RSU's MAC address). */
    struct RsuInfo {
        LAddress::L2Type mac = -1;
        int index = -1;                 // rsu[index]
        bool havePos = false;
        double x = 0, y = 0;            // RSU position announced in the HELLO
        bool heard = false;
        simtime_t firstHello, lastHello;
        long helloRx = 0;
        bool authenticated = false;
        simtime_t lastAuth;
        int retries = 0;                // failed attempts in the current burst
        simtime_t nextTry;
        long attempts = 0, completed = 0, failed = 0;
        double firstHelloToAuth = -1;
        ApbmaAcc latency;
        // diagnostics: how far away was the RSU?
        long failNoM4 = 0, failNoM6 = 0, failLate = 0;
        ApbmaAcc helloDist, distOk, distFail;   // distance [m] at HELLO reception / attempt start (success, failure)
    };

    // ---- members of the original demo application (kept) ----
    simtime_t lastDroveAt;
    bool sentMessage = false;
    int currentSubscribedServiceId = -1;

    // ---- configuration (omnetpp.ini parameters, defaults in the code) ----
    double cfgHelloLifetime = 1.0;      // a HELLO older than this means "RSU not (any more) in range"
    double cfgStartJitter = 0.05;       // spreads the M3 of vehicles that hear the same HELLO
    double cfgTimeout = 0.5;            // M3 start -> M6 verified, otherwise the attempt fails
    double cfgRetryDelay = 0.5;
    int cfgMaxRetries = 3;              // retries in one burst
    double cfgCooldown = 2.0;           // pause after a failed burst, then try again (never gives up for good)
    double cfgMaxAuthDist = 300.0;      // [m] start M3 only if the RSU is closer than this (0 = no limit)
    int cfgRsuSelect = -1;              // -1 = authenticate with every RSU, k = only with rsu[k]
    double cfgBgInterval = 0.0;         // [s] background broadcast traffic of every vehicle (0 = off)
    int bgBytes = 200;                  // payload of a background frame [bytes]
    double cfgCoverageGap = 3.0;        // silence longer than this = a new coverage episode
    double cfgReauthInterval = 0.0;     // 0 = authenticate once per RSU
    double cfgDiagRange = 300.0;        // [m] geometry diagnostics: "in range" distance
    bool cfgVerbose = false;
    int payloadBytes[APBMA_TYPES] = {51, 80, 48, 1621};
    // crypto time model of the OBU [s per operation]  (ASSUMED values: replace by measurements)
    double tHash = 20e-6, tMac = 40e-6, tXor = 1e-6, tPuf = 500e-6, tRnd = 20e-6;
    double tBikeEnc = 800e-6, tBikeDec = 8e-3;
    bool costProfileIsDefault = true;
    // operations of the three vehicle steps (override with apbmaOpsVehM3 / apbmaOpsVehM4 / apbmaOpsVehM6)
    ApbmaOps opsM3, opsM4, opsM6;

    // ---- protocol state ----
    // 0 idle, 1 M3 sent (wait M4), 2 M5 sent (wait M6), 3 M6 received (verifying)
    int apbmaState = 0;
    LAddress::L2Type apbmaRsu = -1;     // RSU of the running handshake
    std::string apbmaSession;
    simtime_t apbmaStart;
    long attemptCounter = 0;
    std::map<LAddress::L2Type, RsuInfo> rsus;
    cMessage* kickEvt = nullptr;        // "look for an RSU to authenticate with"
    cMessage* timeoutEvt = nullptr;
    cMessage* completeEvt = nullptr;
    cMessage* bgEvt = nullptr;          // background traffic timer

    // ---- counters ----
    long txPkts[APBMA_TYPES] = {}, txBytes[APBMA_TYPES] = {}, txBits[APBMA_TYPES] = {};
    long rxPkts[APBMA_TYPES] = {}, rxBytes[APBMA_TYPES] = {};
    long attempts = 0, completed = 0, failed = 0;
    long failNoM4 = 0, failNoM6 = 0, failLate = 0;
    long staleRx = 0, duplicateRx = 0, wrongDestRx = 0;
    long helloRx = 0;
    long bgTx = 0, bgRx = 0, bgTxBytes = 0;
    double rxDelaySum = 0, cryptoSeconds = 0;
    double attemptBytes = 0, attemptCompute = 0, attemptDist = -1;
    ApbmaOps totalOps;
    ApbmaAcc latencyAcc, e2eAcc[APBMA_TYPES], bytesAcc, computeAcc;
    cOutVector latencyVec;

    // ---- geometry diagnostics: how close did this vehicle get to each RSU? ----
    std::vector<BaseMobility*> rsuMobility;
    std::vector<double> minDist, timeInRange;
    simtime_t lastDiag;

    // ---- helpers ----
    double apbmaPar(const char* name, double dflt);
    std::string apbmaStr(const char* name);
    void loadOps(const char* name, ApbmaOps& dst);
    void sendBackground();
    double opSeconds(const ApbmaOps& ops) const;
    void accountCompute(const ApbmaOps& ops, double seconds);
    void scheduleKick(simtime_t when);
    bool eligible(const RsuInfo& r) const;
    void maybeStart();
    void startAttempt(RsuInfo& r);
    void sendApbma(int type, LAddress::L2Type recipient, double computationSeconds);
    void onHello(const ApbmaMsg& m, LAddress::L2Type sender);

    // ---- Veins callbacks ----
    void onWSM(BaseFrame1609_4* wsm) override;
    void onBSM(DemoSafetyMessage* bsm) override;
    void onWSA(DemoServiceAdvertisment* wsa) override;
    void handleSelfMsg(cMessage* msg) override;
    void handlePositionUpdate(cObject* obj) override;
};

} // namespace veins
