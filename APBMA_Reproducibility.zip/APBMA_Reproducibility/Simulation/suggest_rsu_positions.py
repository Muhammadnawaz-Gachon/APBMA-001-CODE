#!/usr/bin/env python3
"""Place the RSUs where the vehicles really drive (or check the positions you already use).

Veins places rsu[k] with *OMNeT++ coordinates* (omnetpp.ini: *.rsu[k].mobility.x / .y), which are NOT the SUMO
coordinates:  x_omnet = x_sumo - xmin + margin,  y_omnet = ymax - y_sumo + margin   (margin = *.manager.margin, 25 m).
An RSU placed off the vehicle routes never hears a vehicle: every APBMA counter stays 0.

    python3 suggest_rsu_positions.py erlangen.sumo.cfg                      # best 2 RSUs for vehicles passing BOTH
    python3 suggest_rsu_positions.py erlangen.sumo.cfg --objective union    # cover as many vehicles as possible
    python3 suggest_rsu_positions.py erlangen.sumo.cfg --check "400,600;900,900"   # judge your current positions
    python3 suggest_rsu_positions.py erlangen.sumo.cfg --fcd fcd.xml        # reuse a previous SUMO trace

Only the Python standard library and a SUMO installation (command `sumo`) are needed.
"""
import argparse
import itertools
import math
import os
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET


def sumo_cfg_files(cfg):
    base = os.path.dirname(os.path.abspath(cfg))
    root = ET.parse(cfg).getroot()
    node = root.find(".//net-file")
    if node is None:
        sys.exit("no <net-file> in " + cfg)
    return os.path.join(base, node.get("value"))


def net_boundary(net):
    with open(net, errors="replace") as fh:
        for line in fh:
            m = re.search(r'convBoundary="([^"]+)"', line)
            if m:
                return [float(v) for v in m.group(1).split(",")]
    sys.exit("no convBoundary in " + net)


def run_sumo(cfg, end, step, out):
    cmd = ["sumo", "-c", cfg, "--fcd-output", out, "--step-length", str(step), "--no-step-log", "true",
           "--no-warnings", "true", "--end", str(end)]
    print("running:", " ".join(cmd), file=sys.stderr)
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=os.path.dirname(os.path.abspath(cfg)))
    if r.returncode != 0:
        sys.exit("SUMO failed:\n" + r.stderr[-800:])


def read_fcd(path, xmin, ymax, margin):
    """Return {vehicle: [(t, x_omnet, y_omnet), ...]}."""
    veh = {}
    t = 0.0
    for _, el in ET.iterparse(path, events=("start",)):
        if el.tag == "timestep":
            t = float(el.get("time"))
        elif el.tag == "vehicle":
            x, y = float(el.get("x")), float(el.get("y"))
            veh.setdefault(el.get("id"), []).append((t, x - xmin + margin, ymax - y + margin))
        el.clear()
    return veh


def covered(veh, cx, cy, radius):
    r2 = radius * radius
    return {v for v, pts in veh.items() if any((x - cx) ** 2 + (y - cy) ** 2 <= r2 for _, x, y in pts)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("sumocfg", help="SUMO configuration (e.g. erlangen.sumo.cfg)")
    ap.add_argument("--n", type=int, default=2, help="number of RSUs (default 2)")
    ap.add_argument("--radius", type=float, default=250.0, help="assumed radio range in metres (default 250)")
    ap.add_argument("--margin", type=float, default=25.0, help="*.manager.margin of omnetpp.ini (default 25)")
    ap.add_argument("--end", type=float, default=300.0, help="SUMO time to analyse [s]")
    ap.add_argument("--step", type=float, default=0.5, help="SUMO step length for the trace [s]")
    ap.add_argument("--cell", type=float, default=25.0, help="candidate grid [m]")
    ap.add_argument("--min-sep", type=float, default=None, help="minimum RSU distance (default: the radius)")
    ap.add_argument("--objective", choices=["both", "union"], default="both",
                    help="both: most vehicles that pass ALL RSUs; union: most vehicles that pass ANY RSU")
    ap.add_argument("--fcd", help="existing SUMO fcd-output file (skips running SUMO)")
    ap.add_argument("--check", help='only evaluate given OMNeT++ positions, e.g. "400,600;900,900"')
    a = ap.parse_args()

    net = sumo_cfg_files(a.sumocfg)
    xmin, ymin, xmax, ymax = net_boundary(net)
    print(f"network {os.path.basename(net)}: SUMO boundary x {xmin:.0f}..{xmax:.0f}, y {ymin:.0f}..{ymax:.0f}  "
          f"->  OMNeT++ playground needs at least {xmax - xmin + 2 * a.margin:.0f} x {ymax - ymin + 2 * a.margin:.0f} m")
    fcd = a.fcd
    if not fcd:
        fcd = os.path.join(tempfile.mkdtemp(), "fcd.xml")
        run_sumo(a.sumocfg, a.end, a.step, fcd)
    veh = read_fcd(fcd, xmin, ymax, a.margin)
    allpts = [(x, y) for pts in veh.values() for _, x, y in pts]
    if not veh:
        sys.exit("no vehicles in the SUMO trace")
    print(f"{len(veh)} vehicles, {len(allpts)} samples; vehicle area in OMNeT++ coordinates: "
          f"x {min(p[0] for p in allpts):.0f}..{max(p[0] for p in allpts):.0f}, "
          f"y {min(p[1] for p in allpts):.0f}..{max(p[1] for p in allpts):.0f}")
    durations = [pts[-1][0] - pts[0][0] for pts in veh.values()]
    print(f"vehicle lifetime in SUMO: min {min(durations):.0f} s, mean {sum(durations) / len(durations):.0f} s, max {max(durations):.0f} s")

    def report(positions, title):
        print(f"\n{title}   (assumed range {a.radius:.0f} m)")
        sets = []
        for k, (cx, cy) in enumerate(positions):
            s = covered(veh, cx, cy, a.radius)
            sets.append(s)
            print(f"  rsu[{k}] at ({cx:.0f}, {cy:.0f}): {len(s)} of {len(veh)} vehicles pass within range")
        inter = set.intersection(*sets) if sets else set()
        union = set.union(*sets) if sets else set()
        print(f"  vehicles passing ANY RSU : {len(union)}   |   passing ALL RSUs: {len(inter)}")
        if not union:
            print("  !! NO vehicle ever comes within range: every APBMA counter will be 0 (this is a placement problem).")
        elif len(union) < 0.5 * len(veh):
            print("  !  fewer than half of the vehicles are covered.")
        return len(union), len(inter)

    if a.check:
        pos = [tuple(float(v) for v in p.split(",")) for p in a.check.split(";")]
        report(pos, "CHECK of the given positions")
        return

    # candidate positions: centres of the grid cells that contain vehicle samples
    cells = {}
    for _, pts in veh.items():
        for _, x, y in pts:
            cells[(int(x // a.cell), int(y // a.cell))] = 1
    cands = [((i + 0.5) * a.cell, (j + 0.5) * a.cell) for (i, j) in cells]
    vlist = sorted(veh)
    index = {v: i for i, v in enumerate(vlist)}
    bits = []
    for cx, cy in cands:
        m = 0
        for v in covered(veh, cx, cy, a.radius):
            m |= 1 << index[v]
        bits.append(m)
    order = sorted(range(len(cands)), key=lambda i: -bin(bits[i]).count("1"))[:500]
    sep = a.radius if a.min_sep is None else a.min_sep

    best, best_score = None, (-1, -1)
    if a.n == 2:
        for i, j in itertools.combinations(order, 2):
            if math.hypot(cands[i][0] - cands[j][0], cands[i][1] - cands[j][1]) < sep:
                continue
            inter = bin(bits[i] & bits[j]).count("1")
            union = bin(bits[i] | bits[j]).count("1")
            score = (inter, union) if a.objective == "both" else (union, inter)
            if score > best_score:
                best, best_score = (i, j), score
    else:  # greedy for n > 2
        chosen, mask = [], 0
        for _ in range(a.n):
            cand = max((i for i in order if all(math.hypot(cands[i][0] - cands[c][0], cands[i][1] - cands[c][1]) >= sep for c in chosen)),
                       key=lambda i: bin(bits[i] & ~mask).count("1"), default=None)
            if cand is None:
                break
            chosen.append(cand)
            mask |= bits[cand]
        best = tuple(chosen)
    if not best:
        sys.exit("no admissible RSU placement found (try a smaller --min-sep or --radius)")
    pos = [cands[i] for i in best]
    report(pos, f"SUGGESTED positions (objective: {a.objective})")
    print("\nPaste into omnetpp.ini (OMNeT++ coordinates):")
    for k, (x, y) in enumerate(pos):
        print(f"*.rsu[{k}].mobility.x = {x:.0f}\n*.rsu[{k}].mobility.y = {y:.0f}\n*.rsu[{k}].mobility.z = 3")
    print(f"\nkeep the playground at least {xmax - xmin + 2 * a.margin:.0f} x {ymax - ymin + 2 * a.margin:.0f} m (*.playgroundSizeX / Y)")


if __name__ == "__main__":
    main()
