#!/usr/bin/env python3
"""APBMA results (M3..M6, node[n] <-> rsu[0], rsu[1], ...) from OMNeT++ result files.

    python3 analyze_apbma.py results/Default/Default-#0.sca
    python3 analyze_apbma.py "results/*/*.sca" --csv runs.csv --json runs.json
    python3 analyze_apbma.py Data-03.csv                       # CSV exported from the OMNeT++ IDE (scalars)

Metrics
  authentication success rate   completed / (completed + timed out); also given coverage, per vehicle and per RSU
  authentication delay          M3 start -> M6 verified (mean, std, min, max; per RSU)
  end-to-end delay              per message and overall (MAC hand-over -> application reception)
  PDR                           received / transmitted frames, per message and overall
  communication cost            payload bytes per successful handshake, per completed authentication, frame bits
  computation cost              crypto operation counts and time (vehicle, RSU), RSU queue wait
  diagnostics                   did vehicles ever come within range of rsu[k]? at what distance did attempts succeed?

Only the Python standard library is needed.
"""
import argparse
import csv
import glob
import json
import math
import os
import re
import sys
from collections import defaultdict

TYPES = ["M3", "M4", "M5", "M6"]
OPS = ["hash", "mac", "xor", "puf", "rnd", "bikeEnc", "bikeDec"]
NAN = float("nan")


class Acc:
    """Mergeable (count, sum, sum of squares, min, max)."""

    def __init__(self):
        self.n, self.s, self.q, self.mn, self.mx = 0.0, 0.0, 0.0, math.inf, -math.inf

    def add_scalars(self, d, base):
        n = d.get(base + "_count", 0)
        if n > 0:
            self.n += n
            self.s += d.get(base + "_sum", 0)
            self.q += d.get(base + "_sqr", 0)
            self.mn = min(self.mn, d.get(base + "_min", math.inf))
            self.mx = max(self.mx, d.get(base + "_max", -math.inf))

    @property
    def mean(self):
        return self.s / self.n if self.n else NAN

    @property
    def std(self):
        if self.n < 2:
            return NAN
        return math.sqrt(max((self.q - self.s * self.s / self.n) / (self.n - 1), 0.0))

    @property
    def lo(self):
        return self.mn if self.n else NAN

    @property
    def hi(self):
        return self.mx if self.n else NAN


# ------------------------------------------------------------------------------------------ input
def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return NAN


def read_sca(path):
    runs, cur = [], None
    with open(path, errors="replace") as fh:
        for line in fh:
            p = line.split(None, 3)
            if not p:
                continue
            if p[0] == "run":
                cur = {"id": p[1] if len(p) > 1 else path, "file": os.path.basename(path), "scalars": []}
                runs.append(cur)
            elif p[0] == "scalar" and cur is not None and len(p) >= 4:
                cur["scalars"].append((p[1], p[2].strip('"'), _num(p[3].split()[0])))
    return runs


def read_csv(path):
    """CSV exported by the OMNeT++ IDE: columns run,type,module,name,attrname,attrvalue,value."""
    runs = {}
    with open(path, newline="", errors="replace") as fh:
        for r in csv.DictReader(fh):
            if r.get("type") != "scalar":
                continue
            run = runs.setdefault(r["run"], {"id": r["run"], "file": os.path.basename(path), "scalars": []})
            run["scalars"].append((r["module"], r["name"], _num(r["value"])))
    return list(runs.values())


# ------------------------------------------------------------------------------------------ analysis
def module_kind(m):
    return "rsu" if re.search(r"\brsu\[\d+\]", m) else "veh"


def analyze(run):
    veh = defaultdict(lambda: defaultdict(float))   # module -> scalar -> value
    rsu = defaultdict(lambda: defaultdict(float))
    for mod, name, val in run["scalars"]:
        if name.startswith("APBMA_") and not math.isnan(val):
            (rsu if module_kind(mod) == "rsu" else veh)[mod][name] += val
    if not veh and not rsu:
        return None
    sv = lambda k: sum(d.get(k, 0) for d in veh.values())
    sr = lambda k: sum(d.get(k, 0) for d in rsu.values())
    sa = lambda k: sv(k) + sr(k)

    def acc(base, mods=None):
        a = Acc()
        for d in (list(veh.values()) + list(rsu.values()) if mods is None else mods):
            a.add_scalars(d, base)
        return a

    r = {"run": run["id"], "file": run["file"], "vehicles": len(veh), "rsus": len(rsu)}
    rsu_ids = sorted({int(re.search(r"rsu\[(\d+)\]", m).group(1)) for m in rsu})
    r["rsu_ids"] = rsu_ids

    # ---- success
    comp, fail, att, infl = sv("APBMA_completed"), sv("APBMA_failed"), sv("APBMA_attempts"), sv("APBMA_inflight")
    reach_fail = sv("APBMA_failNoM6") + sv("APBMA_failLate")
    heard = sum(1 for d in veh.values() if d.get("APBMA_helloRx", 0) > 0)
    authd = sum(1 for d in veh.values() if d.get("APBMA_vehicleAuthenticated", 0) > 0)
    r.update(attempts=att, completed=comp, failed=fail, inflight=infl,
             fail_no_m4=sv("APBMA_failNoM4"), fail_no_m6=sv("APBMA_failNoM6"), fail_late=sv("APBMA_failLate"),
             success_rate=comp / (comp + fail) if comp + fail else NAN,
             success_rate_given_reach=comp / (comp + reach_fail) if comp + reach_fail else NAN,
             vehicles_heard_rsu=heard, vehicles_authenticated=authd,
             vehicle_auth_rate=authd / heard if heard else NAN, hello_rx=sv("APBMA_helloRx"), hello_tx=sr("APBMA_helloTx"))
    k_all = sum(1 for d in veh.values() if rsu_ids and all(d.get(f"APBMA_rsu{k}_authenticated", 0) > 0 for k in rsu_ids))
    r["vehicles_authenticated_with_all_rsus"] = k_all
    r.update(bg_tx=sv("APBMA_bgTx"), bg_rx_vehicles=sv("APBMA_bgRx"), bg_rx_rsus=sr("APBMA_bgRx"))
    cfgd = next((d for d in veh.values() if "APBMA_cfg_timeout_s" in d), {})
    r["cfg"] = {"max_auth_dist_m": cfgd.get("APBMA_cfg_maxAuthDist_m", NAN), "rsu_select": cfgd.get("APBMA_cfg_rsuSelect", NAN),
                "timeout_s": cfgd.get("APBMA_cfg_timeout_s", NAN), "max_retries": cfgd.get("APBMA_cfg_maxRetries", NAN),
                "reauth_s": cfgd.get("APBMA_cfg_reauth_s", NAN), "bg_interval_s": cfgd.get("APBMA_cfg_bgInterval_s", NAN)}

    # ---- per RSU (vehicle side) and RSU side
    per = {}
    for k in rsu_ids:
        p = f"APBMA_rsu{k}_"
        rm = [d for m, d in rsu.items() if f"rsu[{k}]" in m]
        lat, hd, dok, dfl = Acc(), Acc(), Acc(), Acc()
        for d in veh.values():
            lat.add_scalars(d, f"APBMA_rsu{k}_authLatency_s")
            hd.add_scalars(d, f"APBMA_rsu{k}_helloDist_m")
            dok.add_scalars(d, f"APBMA_rsu{k}_distOk_m")
            dfl.add_scalars(d, f"APBMA_rsu{k}_distFail_m")
        a, c, f_ = sv(p + "attempts"), sv(p + "completed"), sv(p + "failed")
        per[k] = {
            "vehicles_in_range": sum(1 for d in veh.values() if d.get(f"APBMA_inRange_rsu{k}_s", 0) > 0),
            "vehicles_heard": sum(1 for d in veh.values() if d.get(p + "helloRx", 0) > 0),
            "vehicles_authenticated": sum(1 for d in veh.values() if d.get(p + "authenticated", 0) > 0),
            "attempts": a, "completed": c, "failed": f_,
            "success_rate": c / (c + f_) if c + f_ else NAN,
            "fail_no_m4": sv(p + "failNoM4"), "fail_no_m6": sv(p + "failNoM6"), "fail_late": sv(p + "failLate"),
            "auth_delay_mean_s": lat.mean, "auth_delay_max_s": lat.hi,
            "hello_dist_mean_m": hd.mean, "hello_dist_max_m": hd.hi,
            "dist_success_mean_m": dok.mean, "dist_failure_mean_m": dfl.mean,
            "min_dist_m": min((d.get(f"APBMA_minDist_rsu{k}_m", math.inf) for d in veh.values()), default=NAN),
            "hello_tx": sum(d.get("APBMA_helloTx", 0) for d in rm),
            "sessions_opened": sum(d.get("APBMA_sessionsOpened", 0) for d in rm),
            "sessions_accepted": sum(d.get("APBMA_sessionsAccepted", 0) for d in rm),
            "unique_vehicles": sum(d.get("APBMA_uniqueVehicles", 0) for d in rm),
            "rsu_crypto_s": sum(d.get("APBMA_cryptoCost_s", 0) for d in rm),
        }
        if per[k]["min_dist_m"] == math.inf:
            per[k]["min_dist_m"] = NAN
    r["per_rsu"] = per

    # ---- authentication delay
    la = acc("APBMA_authLatency_s", list(veh.values()))
    r.update(auth_delay_mean_s=la.mean, auth_delay_std_s=la.std, auth_delay_min_s=la.lo, auth_delay_max_s=la.hi)

    # ---- end-to-end delay and PDR
    tot = Acc()
    ttx = trx = 0.0
    for t in TYPES:
        e = acc(f"APBMA_e2e_{t}_s")
        tx, rx = sa(f"APBMA_tx_{t}_pkts"), sa(f"APBMA_rx_{t}_pkts")
        r[f"e2e_{t}_mean_s"] = e.mean
        r[f"tx_{t}"], r[f"rx_{t}"], r[f"pdr_{t}"] = tx, rx, rx / tx if tx else NAN
        r[f"payload_{t}_bytes"] = sa(f"APBMA_tx_{t}_bytes") / tx if tx else NAN
        tot.n += e.n; tot.s += e.s; ttx += tx; trx += rx
    r["e2e_overall_mean_s"] = tot.mean
    r["pdr_overall"] = trx / ttx if ttx else NAN

    # ---- communication cost
    pay = sum(sa(f"APBMA_tx_{t}_bytes") for t in TYPES)
    bits = sum(sa(f"APBMA_tx_{t}_bits") for t in TYPES)
    ab = acc("APBMA_attemptBytes", list(veh.values()))
    r.update(comm_bytes_per_successful_handshake=ab.mean,
             comm_bytes_per_completed_all_traffic=pay / comp if comp else NAN,
             comm_frame_bits_per_completed=bits / comp if comp else NAN,
             comm_total_payload_bytes=pay, comm_total_frame_bits=bits)

    # ---- computation cost
    ac, qw = acc("APBMA_attemptCompute_s", list(veh.values())), acc("APBMA_queueWait_s", list(rsu.values()))
    vc, rc = sv("APBMA_cryptoCost_s"), sr("APBMA_cryptoCost_s")
    r.update(comp_vehicle_s_per_completed=ac.mean, comp_rsu_s_per_completed=rc / comp if comp else NAN,
             comp_vehicle_total_s=vc, comp_rsu_total_s=rc,
             rsu_queue_wait_mean_s=qw.mean, rsu_queue_wait_max_s=qw.hi)
    for o in OPS:
        r[f"ops_vehicle_{o}_per_completed"] = sv(f"APBMA_ops_{o}") / comp if comp else NAN
        r[f"ops_rsu_{o}_per_completed"] = sr(f"APBMA_ops_{o}") / comp if comp else NAN
    r["assumed_cost_profile"] = bool(sv("APBMA_costProfileIsDefault") or sr("APBMA_costProfileIsDefault"))
    return r


# ------------------------------------------------------------------------------------------ output
def f(v, unit="", scale=1.0):
    if isinstance(v, float):
        return "n/a" if math.isnan(v) else f"{v * scale:.6g}{unit}"
    return f"{v}{unit}"


def report(r):
    p = lambda label, v: print(f"  {label:<52}{v}")
    print(f"\n=== run {r['run']}   ({r['file']}) ===")
    print(f"vehicles: {r['vehicles']}   RSUs: {r['rsus']} {r['rsu_ids']}")

    if r["hello_tx"] > 0 and r["hello_rx"] == 0:
        print("\n  !! The RSUs sent HELLO frames but NO vehicle ever received one: no handshake could start.")
        print("     This is a placement / range problem, not a protocol problem. Closest approach of any vehicle:")
        for k, d in r["per_rsu"].items():
            print(f"       rsu[{k}]: {f(d['min_dist_m'], ' m')}   (vehicles that came within the diagnostic range: {d['vehicles_in_range']})")
        print("     -> run suggest_rsu_positions.py <your .sumo.cfg> --check \"x0,y0;x1,y1\" and move the RSUs onto the routes.")
    c = r["cfg"]
    print(f"  configuration: max auth distance {f(c['max_auth_dist_m'], ' m')} (0 = every HELLO), RSU select {f(c['rsu_select'])} (-1 = all), "
          f"timeout {f(c['timeout_s'], ' s')}, retries {f(c['max_retries'])}, re-auth {f(c['reauth_s'], ' s')}, background {f(c['bg_interval_s'], ' s')}")
    if r["bg_tx"] > 0:
        print(f"  background traffic: {f(r['bg_tx'])} frames sent by the vehicles, heard {f(r['bg_rx_vehicles'])}x by vehicles and {f(r['bg_rx_rsus'])}x by RSUs")
    print("\nAuthentication success")
    p("attempts / completed / failed / in flight", f"{f(r['attempts'])} / {f(r['completed'])} / {f(r['failed'])} / {f(r['inflight'])}")
    p("success rate (all finished attempts)", f(r["success_rate"]))
    p("success rate given the RSU answered (M4 received)", f(r["success_rate_given_reach"]))
    p("failures: no M4 / no M6 / late", f"{f(r['fail_no_m4'])} / {f(r['fail_no_m6'])} / {f(r['fail_late'])}")
    p("vehicles that heard an RSU / authenticated", f"{f(r['vehicles_heard_rsu'])} / {f(r['vehicles_authenticated'])}  (rate {f(r['vehicle_auth_rate'])})")
    p("vehicles authenticated with ALL RSUs", f(r["vehicles_authenticated_with_all_rsus"]))

    print("\nPer RSU  (node[n] <-> rsu[k])")
    print(f"  {'':8}{'in range':>9}{'heard':>7}{'authd':>7}{'attempts':>9}{'ok':>6}{'fail':>6}{'succ.rate':>10}{'delay[ms]':>11}{'min dist[m]':>12}")
    for k, d in r["per_rsu"].items():
        print(f"  rsu[{k}]  {d['vehicles_in_range']:>9}{d['vehicles_heard']:>7}{d['vehicles_authenticated']:>7}{d['attempts']:>9.0f}"
              f"{d['completed']:>6.0f}{d['failed']:>6.0f}{f(d['success_rate']):>10}{f(d['auth_delay_mean_s'], '', 1e3):>11}{f(d['min_dist_m']):>12}")
    for k, d in r["per_rsu"].items():
        if d["failed"] or d["completed"]:
            print(f"  rsu[{k}] distance [m]: HELLO heard up to {f(d['hello_dist_max_m'])}; attempts that succeeded started at mean "
                  f"{f(d['dist_success_mean_m'])}, failed at mean {f(d['dist_failure_mean_m'])}  (no M4 {f(d['fail_no_m4'])}, no M6 {f(d['fail_no_m6'])})")

    print("\nAuthentication delay (M3 start -> M6 verified)")
    p("mean / std", f"{f(r['auth_delay_mean_s'], ' s')} / {f(r['auth_delay_std_s'], ' s')}")
    p("min / max", f"{f(r['auth_delay_min_s'], ' s')} / {f(r['auth_delay_max_s'], ' s')}")

    print("\nEnd-to-end delay and PDR per message")
    print(f"  {'msg':<6}{'tx':>8}{'rx':>8}{'PDR':>9}{'e2e [ms]':>12}{'payload [B]':>13}")
    for t in TYPES:
        e = r[f"e2e_{t}_mean_s"]
        print(f"  {t:<6}{r[f'tx_{t}']:>8.0f}{r[f'rx_{t}']:>8.0f}{f(r[f'pdr_{t}']):>9}{f(e, '', 1e3):>12}{f(r[f'payload_{t}_bytes']):>13}")
    p("overall PDR / e2e delay", f"{f(r['pdr_overall'])} / {f(r['e2e_overall_mean_s'], ' ms', 1e3)}")

    print("\nCommunication cost")
    p("payload bytes per successful handshake", f(r["comm_bytes_per_successful_handshake"], " B"))
    p("payload bytes per completed auth (all traffic)", f(r["comm_bytes_per_completed_all_traffic"], " B"))
    p("on-air frame bits per completed auth", f(r["comm_frame_bits_per_completed"], " bit"))

    print("\nComputation cost")
    p("vehicle crypto time per handshake", f(r["comp_vehicle_s_per_completed"], " ms", 1e3))
    p("RSU crypto time per completed auth", f(r["comp_rsu_s_per_completed"], " ms", 1e3))
    p("RSU queue wait mean / max", f"{f(r['rsu_queue_wait_mean_s'], ' ms', 1e3)} / {f(r['rsu_queue_wait_max_s'], ' ms', 1e3)}")
    for who in ("vehicle", "rsu"):
        ops = ", ".join(f"{o}={f(r[f'ops_{who}_{o}_per_completed'])}" for o in OPS
                        if r[f"ops_{who}_{o}_per_completed"] == r[f"ops_{who}_{o}_per_completed"] and r[f"ops_{who}_{o}_per_completed"] > 0)
        p(f"operations per completed auth ({who})", ops or "n/a")
    if r["assumed_cost_profile"]:
        print("  ! computation TIME uses the built-in ASSUMED profile; replace apbmaTime* by measured values "
              "(operation counts are exact).")


def flat(r):
    out = {k: v for k, v in r.items() if k not in ("per_rsu", "cfg")}
    for k, v in r["cfg"].items():
        out["cfg_" + k] = v
    out["rsu_ids"] = " ".join(map(str, r["rsu_ids"]))
    for k, d in r["per_rsu"].items():
        for name, v in d.items():
            out[f"rsu{k}_{name}"] = v
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help=".sca files, IDE-exported .csv files or glob patterns")
    ap.add_argument("--csv", help="write one row per run")
    ap.add_argument("--json", help="write all metrics as JSON")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    paths = sorted({p for pat in a.files for p in (glob.glob(pat, recursive=True) or [pat])})
    rows = []
    for path in paths:
        if not os.path.exists(path):
            print(f"file not found: {path}", file=sys.stderr)
            continue
        runs = read_csv(path) if path.lower().endswith(".csv") else read_sca(path)
        for run in runs:
            r = analyze(run)
            if r:
                rows.append(r)
    if not rows:
        print("no APBMA_* scalars found (simulation not run with the final TraCIDemo11p / TraCIDemoRSU11p?)", file=sys.stderr)
        return 1
    if not a.quiet:
        for r in rows:
            report(r)
    if a.csv:
        flat_rows = [flat(r) for r in rows]
        keys = sorted({k for r in flat_rows for k in r})
        with open(a.csv, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=keys)
            w.writeheader()
            w.writerows(flat_rows)
        print(f"\nCSV written to {a.csv}")
    if a.json:
        with open(a.json, "w") as fh:
            json.dump(rows, fh, indent=2, default=lambda x: None)
        print(f"JSON written to {a.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
