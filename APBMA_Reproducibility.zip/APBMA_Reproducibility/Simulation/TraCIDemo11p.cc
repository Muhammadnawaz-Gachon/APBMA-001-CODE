#include "veins/modules/application/traci/TraCIDemo11p.h"
#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <limits>
#include <string>

using namespace veins;
Define_Module(veins::TraCIDemo11p);

namespace {

/** Records an accumulator as plain scalars: <name>_count/_sum/_sqr/_min/_max/_mean. */
template <class Rec>
void recAcc(Rec&& rec, const std::string& name, const ApbmaAcc& a)
{
    rec(name + "_count", static_cast<double>(a.n));
    if (a.n > 0) {
        rec(name + "_sum", a.sum);
        rec(name + "_sqr", a.sqr);
        rec(name + "_min", a.mn);
        rec(name + "_max", a.mx);
        rec(name + "_mean", a.sum / static_cast<double>(a.n));
    }
}

} // namespace

// ---------------------------------------------------------------------------------------------
// lifecycle
// ---------------------------------------------------------------------------------------------
TraCIDemo11p::~TraCIDemo11p()
{
    cancelAndDelete(kickEvt);
    cancelAndDelete(timeoutEvt);
    cancelAndDelete(completeEvt);
    cancelAndDelete(bgEvt);
}

double TraCIDemo11p::apbmaPar(const char* name, double dflt)
{
    // Parameters are optional (the NED file may not declare them). OMNeT++ 6 does not convert between
    // parameter types, so read the value according to its declared type.
    if (!hasPar(name)) return dflt;
    const cPar& p = par(name);
    switch (p.getType()) {
    case cPar::DOUBLE: return p.doubleValue();
    case cPar::INT: return static_cast<double>(p.intValue());
    case cPar::BOOL: return p.boolValue() ? 1.0 : 0.0;
    default: return dflt;
    }
}

std::string TraCIDemo11p::apbmaStr(const char* name)
{
    if (!hasPar(name)) return "";
    const cPar& p = par(name);
    return p.getType() == cPar::STRING ? std::string(p.stringValue()) : std::string();
}

void TraCIDemo11p::loadOps(const char* name, ApbmaOps& dst)
{
    const std::string spec = apbmaStr(name);
    if (spec.empty()) return; // keep the built-in default
    ApbmaOps o;
    if (!apbmaParseOps(spec, o))
        throw cRuntimeError("APBMA: bad operation list '%s' for %s (use e.g. \"mac=2,xor=1,puf=1\"; keys: hash mac xor puf rnd bikeEnc bikeDec)", spec.c_str(), name);
    dst = o;
}

void TraCIDemo11p::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        sentMessage = false;
        lastDroveAt = simTime();
        currentSubscribedServiceId = -1;
    }
    else if (stage == 1) {
        // fail fast if the seconds -> simtime_t conversion ever truncates (see apbmaSecs())
        if (std::fabs(apbmaSecs(0.35).dbl() - 0.35) > 1e-9) throw cRuntimeError("APBMA: seconds->simtime_t conversion is broken");

        cfgHelloLifetime = apbmaPar("apbmaHelloLifetime", cfgHelloLifetime);
        cfgStartJitter = apbmaPar("apbmaStartJitter", cfgStartJitter);
        cfgTimeout = apbmaPar("apbmaTimeout", cfgTimeout);
        cfgRetryDelay = apbmaPar("apbmaRetryDelay", cfgRetryDelay);
        cfgMaxRetries = static_cast<int>(apbmaPar("apbmaMaxRetries", cfgMaxRetries));
        cfgCooldown = apbmaPar("apbmaCooldown", cfgCooldown);
        cfgCoverageGap = apbmaPar("apbmaCoverageGap", cfgCoverageGap);
        cfgReauthInterval = apbmaPar("apbmaReauthInterval", cfgReauthInterval);
        cfgDiagRange = apbmaPar("apbmaDiagRange", cfgDiagRange);
        cfgMaxAuthDist = apbmaPar("apbmaMaxAuthDist", cfgMaxAuthDist);
        cfgRsuSelect = static_cast<int>(apbmaPar("apbmaRsuSelect", cfgRsuSelect));
        cfgBgInterval = apbmaPar("apbmaBgInterval", cfgBgInterval);
        bgBytes = static_cast<int>(apbmaPar("apbmaBgBytes", bgBytes));
        cfgVerbose = apbmaPar("apbmaVerbose", 0) != 0;
        payloadBytes[APBMA_T_M3] = static_cast<int>(apbmaPar("apbmaM3Bytes", payloadBytes[APBMA_T_M3]));
        payloadBytes[APBMA_T_M4] = static_cast<int>(apbmaPar("apbmaM4Bytes", payloadBytes[APBMA_T_M4]));
        payloadBytes[APBMA_T_M5] = static_cast<int>(apbmaPar("apbmaM5Bytes", payloadBytes[APBMA_T_M5]));
        payloadBytes[APBMA_T_M6] = static_cast<int>(apbmaPar("apbmaM6Bytes", payloadBytes[APBMA_T_M6]));
        tHash = apbmaPar("apbmaTimeHash", tHash);
        tMac = apbmaPar("apbmaTimeMac", tMac);
        tXor = apbmaPar("apbmaTimeXor", tXor);
        tPuf = apbmaPar("apbmaTimePuf", tPuf);
        tRnd = apbmaPar("apbmaTimeRnd", tRnd);
        tBikeEnc = apbmaPar("apbmaTimeBikeEnc", tBikeEnc);
        tBikeDec = apbmaPar("apbmaTimeBikeDec", tBikeDec);
        // flag results that still use the built-in ASSUMED crypto timing profile (replace by measured values)
        auto near = [](double a, double b) { return std::fabs(a - b) <= 1e-9 * std::fabs(b); };
        costProfileIsDefault = near(tHash, 20e-6) && near(tMac, 40e-6) && near(tPuf, 500e-6) &&
                               near(tBikeEnc, 800e-6) && near(tBikeDec, 8e-3);

        // operations per protocol step (defaults = the hardened APBMA; override with apbmaOps* strings)
        opsM3.rnd = 1;                                                    // N1, alpha = H_theta(N1||ID)
        opsM3.mac = 1;
        opsM4.mac = 2; opsM4.xr = 2; opsM4.puf = 1; opsM4.hash = 1; opsM4.rnd = 1;  // verify Y, PUF, j
        opsM6.bikeDec = 1; opsM6.mac = 1;                                 // BIKE decaps, verify tag
        loadOps("apbmaOpsVehM3", opsM3);
        loadOps("apbmaOpsVehM4", opsM4);
        loadOps("apbmaOpsVehM6", opsM6);
        if (cfgBgInterval < 0 || (cfgBgInterval > 0 && cfgBgInterval < 0.001)) throw cRuntimeError("apbmaBgInterval must be 0 (off) or at least 1 ms");

        kickEvt = new cMessage("APBMA_KICK");
        timeoutEvt = new cMessage("APBMA_TIMEOUT");
        completeEvt = new cMessage("APBMA_COMPLETE");
        bgEvt = new cMessage("APBMA_BG");
        if (cfgBgInterval > 0) scheduleAt(simTime() + apbmaSecs(uniform(0, cfgBgInterval)), bgEvt);
        latencyVec.setName("APBMA_authLatency_vec");

        // geometry diagnostics: locate every RSU of the network (rsu[0], rsu[1], ...)
        cModule* net = getSimulation()->getSystemModule();
        int n = net->getSubmoduleVectorSize("rsu");
        if (n < 0) n = 0;
        for (int k = 0; k < n; k++) {
            cModule* r = net->getSubmodule("rsu", k);
            cModule* m = r ? r->getSubmodule("mobility") : nullptr;
            rsuMobility.push_back(m ? dynamic_cast<BaseMobility*>(m) : nullptr);
        }
        minDist.assign(n, std::numeric_limits<double>::infinity());
        timeInRange.assign(n, 0.0);
        lastDiag = simTime();
    }
}

// ---------------------------------------------------------------------------------------------
// crypto time model
// ---------------------------------------------------------------------------------------------
double TraCIDemo11p::opSeconds(const ApbmaOps& o) const
{
    return o.hash * tHash + o.mac * tMac + o.xr * tXor + o.puf * tPuf + o.rnd * tRnd + o.bikeEnc * tBikeEnc +
           o.bikeDec * tBikeDec;
}

void TraCIDemo11p::accountCompute(const ApbmaOps& ops, double seconds)
{
    totalOps += ops;
    cryptoSeconds += seconds;
    attemptCompute += seconds;
}

// ---------------------------------------------------------------------------------------------
// choosing the RSU to authenticate with
// ---------------------------------------------------------------------------------------------
void TraCIDemo11p::scheduleKick(simtime_t when)
{
    if (when < simTime()) when = simTime();
    if (kickEvt->isScheduled()) {
        if (kickEvt->getArrivalTime() <= when) return;
        cancelEvent(kickEvt);
    }
    scheduleAt(when, kickEvt);
}

bool TraCIDemo11p::eligible(const RsuInfo& r) const
{
    const simtime_t now = simTime();
    if (!r.heard || (now - r.lastHello).dbl() > cfgHelloLifetime) return false; // not (any more) in range
    if (cfgRsuSelect >= 0 && r.index != cfgRsuSelect) return false;               // this RSU is not part of the experiment
    if (r.authenticated && !(cfgReauthInterval > 0 && (now - r.lastAuth).dbl() >= cfgReauthInterval)) return false;
    if (cfgMaxAuthDist > 0 && r.havePos && std::hypot(curPosition.x - r.x, curPosition.y - r.y) > cfgMaxAuthDist)
        return false;                                                           // too far for a reliable handshake
    return now >= r.nextTry;
}

void TraCIDemo11p::maybeStart()
{
    if (apbmaState != 0) return; // one handshake at a time
    const simtime_t now = simTime();
    RsuInfo* best = nullptr;
    double bestKey = std::numeric_limits<double>::infinity();
    bool pending = false;
    simtime_t earliest;
    for (auto& kv : rsus) {
        RsuInfo& r = kv.second;
        if (eligible(r)) {
            // nearest RSU first (position is announced in the HELLO); otherwise the most recently heard
            const double key = r.havePos ? std::hypot(curPosition.x - r.x, curPosition.y - r.y) : 1e9 - r.lastHello.dbl();
            if (key < bestKey) {
                best = &r;
                bestKey = key;
            }
        }
        else if (r.heard && (now - r.lastHello).dbl() <= cfgHelloLifetime && (cfgRsuSelect < 0 || r.index == cfgRsuSelect)) {
            // in range, but must wait (retry back-off or periodic re-authentication)
            simtime_t t = r.nextTry;
            if (r.authenticated) {
                if (cfgReauthInterval <= 0) continue;
                t = std::max(t, r.lastAuth + apbmaSecs(cfgReauthInterval));
            }
            if (t > now && (!pending || t < earliest)) {
                pending = true;
                earliest = t;
            }
        }
    }
    if (best)
        startAttempt(*best);
    else if (pending)
        scheduleKick(earliest);
}

void TraCIDemo11p::onHello(const ApbmaMsg& m, LAddress::L2Type sender)
{
    const simtime_t now = simTime();
    RsuInfo& r = rsus[sender];
    if (!r.heard) {
        r.mac = sender;
        r.heard = true;
        r.firstHello = now;
    }
    else if ((now - r.lastHello).dbl() > cfgCoverageGap) {
        r.retries = 0; // left the coverage and came back: a new episode, try again
        r.nextTry = now;
    }
    r.index = std::atoi(m.session.c_str());
    if (m.hasPos) {
        r.havePos = true;
        r.x = m.x;
        r.y = m.y;
    }
    r.lastHello = now;
    r.helloRx++;
    helloRx++;
    if (r.havePos) r.helloDist.add(std::hypot(curPosition.x - r.x, curPosition.y - r.y));
    // vehicles that hear the same HELLO must not all send M3 at the same instant
    if (apbmaState == 0) scheduleKick(now + apbmaSecs(uniform(0, cfgStartJitter)));
}

// ---------------------------------------------------------------------------------------------
// protocol
// ---------------------------------------------------------------------------------------------
void TraCIDemo11p::startAttempt(RsuInfo& r)
{
    attempts++;
    attemptCounter++;
    r.attempts++;
    apbmaSession = std::to_string(static_cast<long long>(myId)) + "-" + std::to_string(attemptCounter);
    apbmaRsu = r.mac;
    apbmaState = 1;
    apbmaStart = simTime();
    attemptBytes = 0;
    attemptCompute = 0;
    attemptDist = r.havePos ? std::hypot(curPosition.x - r.x, curPosition.y - r.y) : -1;

    // M3: N1 <- rnd, alpha = H_theta(N1 || ID_V)   (ID_V = h(GTMA||R) is stored since registration)
    const ApbmaOps ops = opsM3;
    const double c = opSeconds(ops);
    accountCompute(ops, c);

    if (timeoutEvt->isScheduled()) cancelEvent(timeoutEvt);
    scheduleAt(apbmaStart + apbmaSecs(cfgTimeout), timeoutEvt);
    if (cfgVerbose) EV_INFO << "APBMA node " << myId << " -> rsu[" << r.index << "] M3 session " << apbmaSession << "\n";
    sendApbma(APBMA_T_M3, r.mac, c); // unicast to the RSU that announced itself
}

void TraCIDemo11p::sendApbma(int type, LAddress::L2Type recipient, double computationSeconds)
{
    auto* pkt = new TraCIDemo11pMessage();
    populateWSM(pkt, recipient);
    pkt->setSenderAddress(myId); // the RSU answers with a unicast to this address

    // the frame reaches the MAC after the computation delay: stamp that instant, so that the measured
    // end-to-end delay is a pure communication delay (queueing + airtime + propagation)
    const simtime_t delay = apbmaSecs(computationSeconds);
    const simtime_t txTime = simTime() + delay;
    std::ostringstream data;
    data << "APBMA|" << apbmaTypeName(type) << "|" << apbmaSession << "|" << txTime.raw();
    pkt->setDemoData(data.str().c_str());

    // logical APBMA payload size (replaces the default dataLengthBits of populateWSM)
    pkt->setBitLength(headerLength + 8 * payloadBytes[type]);

    txPkts[type]++;
    txBytes[type] += payloadBytes[type];
    txBits[type] += pkt->getBitLength();
    attemptBytes += payloadBytes[type];
    sendDelayedDown(pkt, delay);
}

void TraCIDemo11p::sendBackground()
{
    auto* pkt = new TraCIDemo11pMessage();
    populateWSM(pkt, LAddress::L2BROADCAST());
    pkt->setSenderAddress(myId);
    std::ostringstream data;
    data << "APBMA|BG|" << myId << "|" << simTime().raw();
    pkt->setDemoData(data.str().c_str());
    pkt->setBitLength(headerLength + 8 * bgBytes);
    sendDown(pkt);
    bgTx++;
    bgTxBytes += bgBytes;
}

void TraCIDemo11p::onWSM(BaseFrame1609_4* frame)
{
    auto* pkt = dynamic_cast<TraCIDemo11pMessage*>(frame);
    if (!pkt) return;
    ApbmaMsg m;
    if (!apbmaParse(pkt->getDemoData(), m)) return;

    if (m.type == APBMA_T_BG) {
        bgRx++; // background frame of another vehicle: only load on the channel
        return;
    }
    if (m.type == APBMA_T_HELLO) {
        onHello(m, pkt->getSenderAddress());
        return;
    }
    // only M4 / M6 are addressed to a vehicle (M3 / M5 of other vehicles never reach the application: unicast)
    if (m.type != APBMA_T_M4 && m.type != APBMA_T_M6) return;
    if (pkt->getRecipientAddress() != myId) {
        wrongDestRx++;
        return;
    }

    SimTime tx;
    tx.setRaw(m.txRaw);
    const double d = (simTime() - tx).dbl();
    rxPkts[m.type]++;
    rxBytes[m.type] += payloadBytes[m.type];
    rxDelaySum += d;
    e2eAcc[m.type].add(d);

    if (m.session != apbmaSession || pkt->getSenderAddress() != apbmaRsu) {
        staleRx++; // answer of an attempt that has already ended, or of another RSU
        return;
    }

    if (m.type == APBMA_T_M4) {
        if (apbmaState != 1) {
            duplicateRx++;
            return;
        }
        attemptBytes += payloadBytes[APBMA_T_M4];
        apbmaState = 2;
        // M4 handling: verify Y (MAC), C = omega xor theta, R = P(C) (PUF), beta' = h(R), beta = omega xor C,
        //              N3 <- rnd, j = H_theta(N2||N3||C||R)
        const ApbmaOps ops = opsM4;
        const double c = opSeconds(ops);
        accountCompute(ops, c);
        sendApbma(APBMA_T_M5, apbmaRsu, c);
    }
    else { // APBMA_T_M6
        if (apbmaState != 2) {
            duplicateRx++;
            return;
        }
        attemptBytes += payloadBytes[APBMA_T_M6];
        apbmaState = 3;
        // M6 handling: BIKE decapsulation (syndrome, BGF decode, e''=e'), K_S, verify tag (MAC)
        const ApbmaOps ops = opsM6;
        const double c = opSeconds(ops);
        accountCompute(ops, c);
        // the handshake is complete only after the vehicle has finished verifying M6
        scheduleAt(simTime() + apbmaSecs(c), completeEvt);
    }
}

void TraCIDemo11p::handleSelfMsg(cMessage* msg)
{
    if (msg == kickEvt) {
        maybeStart();
    }
    else if (msg == bgEvt) {
        sendBackground();
        scheduleAt(simTime() + apbmaSecs(cfgBgInterval), bgEvt);
    }
    else if (msg == completeEvt) {
        if (apbmaState != 3) return;
        if (timeoutEvt->isScheduled()) cancelEvent(timeoutEvt);
        const simtime_t now = simTime();
        const double latency = (now - apbmaStart).dbl();
        RsuInfo& r = rsus[apbmaRsu];
        completed++;
        r.completed++;
        r.latency.add(latency);
        if (attemptDist >= 0) r.distOk.add(attemptDist);
        r.authenticated = true;
        r.lastAuth = now;
        r.retries = 0;
        if (r.firstHelloToAuth < 0) r.firstHelloToAuth = (now - r.firstHello).dbl();
        latencyAcc.add(latency);
        latencyVec.record(latency);
        bytesAcc.add(attemptBytes);
        computeAcc.add(attemptCompute);
        if (cfgVerbose) EV_INFO << "APBMA node " << myId << " authenticated with rsu[" << r.index << "] in " << latency << " s\n";
        apbmaState = 0;
        apbmaRsu = -1;
        scheduleKick(now); // another RSU may be waiting
    }
    else if (msg == timeoutEvt) {
        if (apbmaState == 0) return;
        failed++;
        if (apbmaState == 1) failNoM4++;       // M3 or M4 lost / RSU out of range
        else if (apbmaState == 2) failNoM6++;  // M5 or M6 lost
        else failLate++;                       // M6 arrived but verification finished too late
        RsuInfo& r = rsus[apbmaRsu];
        r.failed++;
        if (apbmaState == 1) r.failNoM4++;
        else if (apbmaState == 2) r.failNoM6++;
        else r.failLate++;
        if (attemptDist >= 0) r.distFail.add(attemptDist);
        r.retries++;
        if (r.retries > cfgMaxRetries) {
            // a burst of failures: pause, then start over (the vehicle may have come closer meanwhile)
            r.retries = 0;
            r.nextTry = simTime() + apbmaSecs(cfgCooldown);
        }
        else {
            r.nextTry = simTime() + apbmaSecs(cfgRetryDelay);
        }
        if (completeEvt->isScheduled()) cancelEvent(completeEvt);
        apbmaState = 0;
        apbmaRsu = -1;
        scheduleKick(simTime()); // try another RSU, or wake up when the back-off of this one ends
    }
    else {
        DemoBaseApplLayer::handleSelfMsg(msg);
    }
}

void TraCIDemo11p::onBSM(DemoSafetyMessage* bsm)
{
    // APBMA discovery uses its own HELLO frames; beacons are not used
}

void TraCIDemo11p::onWSA(DemoServiceAdvertisment* wsa)
{
    // APBMA uses the default CCH, no service channel switching needed
}

void TraCIDemo11p::handlePositionUpdate(cObject* obj)
{
    DemoBaseApplLayer::handlePositionUpdate(obj);
    lastDroveAt = simTime();

    // geometry diagnostics: closest approach and time spent within range of every RSU
    const double dt = (simTime() - lastDiag).dbl();
    lastDiag = simTime();
    for (size_t k = 0; k < rsuMobility.size(); k++) {
        if (!rsuMobility[k]) continue;
        const Coord p = rsuMobility[k]->getPositionAt(simTime());
        const double d = std::hypot(curPosition.x - p.x, curPosition.y - p.y);
        if (d < minDist[k]) minDist[k] = d;
        if (d <= cfgDiagRange) timeInRange[k] += dt;
    }
}

// ---------------------------------------------------------------------------------------------
// results (plain scalars only: usable from .sca files and from the IDE's CSV export)
// ---------------------------------------------------------------------------------------------
void TraCIDemo11p::finish()
{
    auto rec = [this](const std::string& n, double v) { recordScalar(n.c_str(), v); };
    const long inflight = (apbmaState != 0) ? 1 : 0; // handshake still running when the vehicle left / sim ended

    rec("APBMA_nodeIndex", getParentModule()->getIndex());
    long totTx = 0, totRx = 0, totTxBytes = 0;
    for (int i = 0; i < APBMA_TYPES; i++) {
        totTx += txPkts[i];
        totRx += rxPkts[i];
        totTxBytes += txBytes[i];
        const std::string t = apbmaTypeName(i);
        rec("APBMA_tx_" + t + "_pkts", txPkts[i]);
        rec("APBMA_tx_" + t + "_bytes", txBytes[i]);
        rec("APBMA_tx_" + t + "_bits", txBits[i]);
        rec("APBMA_rx_" + t + "_pkts", rxPkts[i]);
        rec("APBMA_rx_" + t + "_bytes", rxBytes[i]);
        recAcc(rec, "APBMA_e2e_" + t + "_s", e2eAcc[i]);
    }
    // names of the original version are kept for existing post-processing
    rec("APBMA_txPackets", totTx);
    rec("APBMA_rxPackets", totRx);
    rec("APBMA_txPayloadBytes", totTxBytes);
    rec("APBMA_rxDelaySum_s", rxDelaySum);
    rec("APBMA_cryptoCost_s", cryptoSeconds);
    rec("APBMA_attempts", attempts);
    rec("APBMA_completed", completed);

    rec("APBMA_failed", failed);
    rec("APBMA_failNoM4", failNoM4);
    rec("APBMA_failNoM6", failNoM6);
    rec("APBMA_failLate", failLate);
    rec("APBMA_inflight", inflight);
    rec("APBMA_staleRx", staleRx);
    rec("APBMA_duplicateRx", duplicateRx);
    rec("APBMA_wrongDestRx", wrongDestRx);
    rec("APBMA_helloRx", helloRx);
    rec("APBMA_bgTx", bgTx);
    rec("APBMA_bgRx", bgRx);
    rec("APBMA_bgTxBytes", bgTxBytes);
    // the configuration is stored with the results, so that runs can be compared later
    rec("APBMA_cfg_maxAuthDist_m", cfgMaxAuthDist);
    rec("APBMA_cfg_rsuSelect", cfgRsuSelect);
    rec("APBMA_cfg_timeout_s", cfgTimeout);
    rec("APBMA_cfg_maxRetries", cfgMaxRetries);
    rec("APBMA_cfg_reauth_s", cfgReauthInterval);
    rec("APBMA_cfg_bgInterval_s", cfgBgInterval);

    // per RSU: node[n] <-> rsu[k]
    long authRsus = 0;
    for (const auto& kv : rsus) {
        const RsuInfo& r = kv.second;
        const std::string p = "APBMA_rsu" + std::to_string(r.index) + "_";
        rec(p + "helloRx", r.helloRx);
        rec(p + "attempts", r.attempts);
        rec(p + "completed", r.completed);
        rec(p + "failed", r.failed);
        rec(p + "authenticated", r.authenticated ? 1 : 0);
        if (r.firstHelloToAuth >= 0) rec(p + "firstHelloToAuth_s", r.firstHelloToAuth);
        recAcc(rec, "APBMA_rsu" + std::to_string(r.index) + "_authLatency_s", r.latency);
        rec(p + "failNoM4", r.failNoM4);
        rec(p + "failNoM6", r.failNoM6);
        rec(p + "failLate", r.failLate);
        recAcc(rec, "APBMA_rsu" + std::to_string(r.index) + "_helloDist_m", r.helloDist);
        recAcc(rec, "APBMA_rsu" + std::to_string(r.index) + "_distOk_m", r.distOk);
        recAcc(rec, "APBMA_rsu" + std::to_string(r.index) + "_distFail_m", r.distFail);
        if (r.authenticated) authRsus++;
    }
    rec("APBMA_rsusHeard", static_cast<double>(rsus.size()));
    rec("APBMA_rsusAuthenticated", authRsus);
    rec("APBMA_vehicleAuthenticated", authRsus > 0 ? 1 : 0);

    // geometry diagnostics: why did (or didn't) this vehicle talk to an RSU?
    for (size_t k = 0; k < minDist.size(); k++) {
        if (std::isfinite(minDist[k])) rec("APBMA_minDist_rsu" + std::to_string(k) + "_m", minDist[k]);
        rec("APBMA_inRange_rsu" + std::to_string(k) + "_s", timeInRange[k]);
    }

    rec("APBMA_ops_hash", totalOps.hash);
    rec("APBMA_ops_mac", totalOps.mac);
    rec("APBMA_ops_xor", totalOps.xr);
    rec("APBMA_ops_puf", totalOps.puf);
    rec("APBMA_ops_rnd", totalOps.rnd);
    rec("APBMA_ops_bikeEnc", totalOps.bikeEnc);
    rec("APBMA_ops_bikeDec", totalOps.bikeDec);
    rec("APBMA_costProfileIsDefault", costProfileIsDefault ? 1 : 0);

    recAcc(rec, "APBMA_authLatency_s", latencyAcc);
    recAcc(rec, "APBMA_attemptBytes", bytesAcc);
    recAcc(rec, "APBMA_attemptCompute_s", computeAcc);
    DemoBaseApplLayer::finish();
}
