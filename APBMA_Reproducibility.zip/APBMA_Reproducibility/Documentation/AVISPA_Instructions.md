# AVISPA Instructions — see Formal_Verification/AVISPA/AVISPA_Instructions.md

To avoid maintaining two copies of the same instructions, the full AVISPA installation,
execution, and result-interpretation guide lives next to the model it documents:

➡ **[`../Formal_Verification/AVISPA/AVISPA_Instructions.md`](../Formal_Verification/AVISPA/AVISPA_Instructions.md)**

Verification status/results: `../Formal_Verification/AVISPA/Verification_Results/NOTE.md`
