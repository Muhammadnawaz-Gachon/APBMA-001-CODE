# Installation and Requirements — APBMA Reproducibility Package

## Software versions used to produce the published simulation results

| Component | Version actually used | Notes |
|---|---|---|
| Operating system | Ubuntu 24.04 LTS (noble), x86_64 | Linux kernel 5.4.0-173-generic |
| OMNeT++ | 6.0.3 | built from the `omnetpp-6.0.3` branch/release |
| Veins | 5.3.1 (also compiles cleanly against 5.2) | built from the `veins-5.3.1` branch |
| SUMO | 1.18.0 | `apt`-installed `sumo`/`sumo-gui` package |
| Compiler | GCC 13.2.0 | as shipped with Ubuntu 24.04 |
| Python (for `analyze_apbma.py`) | Python 3, with `pandas` and `numpy` | any recent Python 3.x should work |
| Scyther | built from `cascremers/scyther` GitHub `main` branch (no tagged release / version number) | see `Formal_Verification/Scyther/Scyther_Instructions.md` |
| AVISPA | not yet run for this repository — version to be filled in once executed | see `Formal_Verification/AVISPA/AVISPA_Instructions.md` |

If you use different (e.g. newer) versions of OMNeT++/Veins/SUMO, the simulation is expected to
still run — the `.ini`/`.ned`/`.cc`/`.h` files use only standard, stable Veins/OMNeT++ 6.x APIs —
but exact numerical results (especially timing-sensitive ones) may differ slightly; report the
versions you actually used alongside any reproduced numbers.

## 1. Install OMNeT++

1. Download OMNeT++ 6.0.3 (or compatible 6.x) from `https://omnetpp.org/download/`.
2. Extract it and follow the official `doc/InstallGuide.pdf` for your OS (on Linux: install the
   listed system packages, run `./configure`, then `make -j$(nproc)`).
3. Add `<omnetpp-root>/bin` to your `PATH` and confirm with `opp_run -v`.

## 2. Install Veins

1. Download Veins 5.3.1 (or 5.2) from `https://veins.car2x.org/download/` or
   `git clone --branch veins-5.3.1 https://github.com/sommer/veins.git`.
2. From the Veins source directory, run `./configure` then `make -j$(nproc)` (this requires
   OMNeT++'s environment to be sourced first, e.g. `source <omnetpp-root>/setenv`).
3. Open the Veins `examples/veins/` directory — this contains the stock `RSUExampleScenario`
   this project's `APBMA.ini` relies on (see `../Simulation/README_Simulation_Notes.md`).

## 3. Install SUMO

1. On Ubuntu/Debian: `sudo apt install sumo sumo-tools sumo-doc` (gives SUMO 1.18.0 on Ubuntu
   24.04; other distributions/versions may package a different SUMO release).
2. Alternatively, build from source per `https://sumo.dlr.de/docs/Installing/index.html`.
3. Confirm with `sumo --version`.
4. Set the `SUMO_HOME` environment variable to SUMO's install directory, as Veins' TraCI
   launcher expects it.

## 4. Import the APBMA simulation project

1. Copy the six files from `../Simulation/` (`APBMA.ini`, `TraCIDemo11p.{h,cc,ned}`,
   `TraCIDemoRSU11p.{h,cc,ned}`) into Veins' `examples/veins/` directory, alongside the
   existing `RSUExampleScenario.ned`, `config.xml`, `antenna.xml`, and `erlangen.launchd.xml`
   that ship with Veins.
2. In the OMNeT++ IDE: **File → Import → General → Existing Projects into Workspace**, select
   the Veins checkout (which now contains the APBMA files), and let the IDE index it.

See `Simulation_Instructions.md` for compiling and running the simulation.
