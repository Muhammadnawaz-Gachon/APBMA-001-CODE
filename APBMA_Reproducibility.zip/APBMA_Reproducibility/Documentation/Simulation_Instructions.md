# Simulation Instructions — APBMA

Prerequisite: complete `Installation_and_Requirements.md` first (OMNeT++ 6.0.3, Veins 5.3.1,
SUMO 1.18.0 installed; `APBMA.ini` and the six `TraCIDemo*` files copied into Veins'
`examples/veins/` directory next to the stock `RSUExampleScenario` files).

## 5. Configure the simulation

`APBMA.ini` is self-contained: it declares `[General]` (network, radio, TraCI manager, RSU and
vehicle app settings) and `[Config APBMA]` (RSU positions and the `apbma*` protocol
parameters, each documented inline with its default value). No other `.ini` file needs to be
edited to run the default scenario.

## 6. Compile the C++ source files

From the OMNeT++ IDE: right-click the Veins project → **Build Project** (this compiles
`TraCIDemo11p.cc`/`TraCIDemoRSU11p.cc` along with the rest of Veins).

From the command line, inside the Veins source directory:
```bash
make -j$(nproc)
```

## 7. Execute the simulation

Command line:
```bash
opp_run -r0 -u Cmdenv -c APBMA -n .:<path-to-veins>/src:<path-to-veins>/examples/veins \
  -l <path-to-veins>/src/veins APBMA.ini
```
(or, more simply, from inside the example directory with the Veins makefile's generated
launcher): `./run -u Cmdenv -c APBMA`

From the OMNeT++ IDE: right-click `APBMA.ini` → **Run As → OMNeT++ Simulation**, and select the
`APBMA` configuration in the launch dialog (not `Default`).

SUMO/TraCI starts automatically via `*.manager.launchConfig = xmldoc("erlangen.launchd.xml")`;
no separate manual SUMO launch is required.

## 8. Locate the generated output files

By default OMNeT++ writes, per run, into a `results/` subdirectory next to the `.ini` file:
- `*.sca` — the scalar results file (per-vehicle and per-RSU counters: attempts, completions,
  latency sums, byte/operation counts, etc.).
- `*.vec` — vector results, only for the few vectors enabled in `APBMA.ini`
  (`APBMA_authLatency_vec`).

## 9. Extract and analyze the experimental metrics

Two options:
- **IDE**: open the `.sca` file in the OMNeT++ IDE's Scalars/Vectors browser, or export it to
  CSV (**File → Export**) for use in Excel/pandas — this is the format of the files in
  `../Results/Excel/`.
- **Script**: run
  ```bash
  python3 ../Simulation/analyze_apbma.py <path-to-exported>.csv
  ```
  which prints the six categories of metrics (authentication, delivery, communication,
  computation, latency decomposition, capacity) used in the paper's evaluation section.

## 10. Compare reproduced results against the supplied datasets

The CSV files in `../Results/Excel/` are the exact exports used to produce this project's
evaluation (see `../README.md` for what each file represents). To compare:

1. Run the simulation as above with `APBMA.ini` unmodified for a baseline comparison, or with
   the specific parameter overrides noted for each dataset in the root `README.md`.
2. Export your run's `.sca` file to CSV the same way (OMNeT++ IDE **File → Export → CSV**).
3. Run `analyze_apbma.py` on both your new CSV and the matching supplied CSV, and compare the
   printed metrics (handshake count, mean latency, byte totals, etc.).

Exact numeric agreement is **not** expected if your OMNeT++/Veins/SUMO versions, compiler, or
random seed differ from those listed in `Installation_and_Requirements.md` — timing-sensitive
figures (e.g. crypto cost placeholders in `APBMA.ini`) are simulation inputs, not hardware
measurements, and SUMO route/traffic generation is itself randomized unless a fixed seed is
set. The protocol-level counters (handshake success/failure counts, message counts, byte
totals, operation counts) should match exactly for the same `.ini` settings and SUMO scenario,
since those are deterministic given the same input.
