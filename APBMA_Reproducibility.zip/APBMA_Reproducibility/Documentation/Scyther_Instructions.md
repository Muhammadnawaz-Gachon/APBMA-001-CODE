# Scyther Instructions — see Formal_Verification/Scyther/Scyther_Instructions.md

To avoid maintaining two copies of the same instructions, the full Scyther installation,
execution, and result-interpretation guide lives next to the models it documents:

➡ **[`../Formal_Verification/Scyther/Scyther_Instructions.md`](../Formal_Verification/Scyther/Scyther_Instructions.md)**

Raw verification output: `../Formal_Verification/Scyther/Verification_Results/`
