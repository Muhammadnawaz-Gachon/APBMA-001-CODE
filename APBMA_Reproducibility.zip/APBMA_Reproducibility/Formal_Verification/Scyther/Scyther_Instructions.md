# Scyther Verification Instructions — APBMA

This folder contains two SPDL models of APBMA's run-time phase and the raw verification output
actually produced for them during development (see `Verification_Results/`):

| File                         | Claims / role | Purpose                                              |
|-------------------------------|:---:|--------------------------------------------------------|
| `v2x_hardened.spdl`           |  3  | Fast model: `Reachable`, `Secret(Ks)`, `Nisynch` only  |
| `v2x_hardened_full.spdl`      |  9  | Full model: adds `Secret` of R/C/theta, `Alive`, `Weakagree`, `Niagree` |

**Scyther build used to produce the captured output:** compiled from
`https://github.com/cascremers/scyther` (a shallow `git clone --depth 1` of the `main` branch —
**not** a tagged release, so there is no official version number such as "1.1.3" to report
truthfully; if you install a tagged release instead, record that version number here).
**Operating system used for the captured output:** Ubuntu 24.04 LTS (noble), x86_64, Linux
kernel 5.4.0-173-generic.

## 1. Install and configure Scyther

Option A — prebuilt GUI release (recommended for most users):
1. Download a Scyther release for your OS from `https://people.cispa.io/cas.cremers/scyther/`
   or `https://github.com/cascremers/scyther/releases`.
2. Unpack it; the GUI (`scyther-gui`, Python/Tkinter-based) and a platform-specific command-line
   binary (e.g. `scyther-linux`, `scyther-w32.exe`, `scyther-mac`) are included.
3. Scyther's GUI requires Python 3 and (on Linux) Tkinter (`sudo apt install python3-tk`).

Option B — build from source (what was used to produce the captured output here):
```bash
git clone --depth 1 https://github.com/cascremers/scyther.git
cd scyther
# follow gui/Readme.md / cli/Readme.md for your platform's build dependencies
# (a C compiler, flex, bison, and libgmp-dev on Linux)
cd cli && make
```
This produces a command-line binary such as `scyther-linux` with no bundled version tag.

## 2. Open the model in the Scyther GUI

```bash
scyther-gui v2x_hardened.spdl
```
or use the GUI's "File → Open" dialog to load the file.

## 3. Execute the verification

- From the GUI: click **Verify** (or **Check protocol**) to run the default analysis, or
  **Auto Verify** to check all claims.
- From the command line (used to produce the output in `Verification_Results/`):
  ```bash
  scyther-linux --plain --max-runs=3 v2x_hardened.spdl
  scyther-linux --plain --max-runs=5 v2x_hardened.spdl
  scyther-linux --plain v2x_hardened_full.spdl        # default bound
  ```

## 4. Configure verification settings

- **Roles**: both files declare two roles, `V` (vehicle) and `RSU` (roadside unit); Scyther
  checks the claims of both automatically.
- **Claims**: declared inline in each role with `claim(...)` statements — see the `claim`
  lines near the end of each role in the `.spdl` file for the exact list (`Reachable`,
  `Secret`, `Nisynch`, and in the full model also `Alive`, `Weakagree`, `Niagree`).
- **Analysis parameters**: the `--max-runs=N` flag bounds the number of concurrent protocol
  runs/sessions Scyther explores (a larger bound gives stronger assurance at higher runtime
  cost; Scyther's own default bound was 5 for this model). The GUI exposes the same bound
  under **Verify → Settings → Maximum number of runs**.

## 5. Interpreting the results

Each claim line Scyther prints has the form:
```
<protocol>,<role>,<ClaimLabel> <verdict> [<detail>]
```
- **Ok [no attack within bounds]** — Scyther explored all protocol runs up to the configured
  bound and found no trace violating that claim.
- **Ok [at least 1 variant]** — for `Reachable` claims only: confirms the role can actually
  execute (a sanity check, not a security guarantee).
- **Fail / Attack found** — Scyther found a concrete trace violating the claim; the GUI can
  display this trace graphically. No such line appears in the captured output for either model.
- A claim can also report **Fail: state space exhausted / bound reached** if the bound was too
  small to decide — increase `--max-runs` and re-check if this occurs; it does not happen for
  either file at the bounds used here.

## 6. Security properties explicitly modeled

Only the properties with an actual `claim(...)` line in the `.spdl` file are certified by a
Scyther run; do not report a property beyond what is listed below.

| Property | Modeled as | Present in |
|---|---|---|
| Mutual authentication | `Niagree` (full model) and `Nisynch` (both models) on both roles | both files |
| Session-key secrecy | `claim(..., Secret, Ks)` | both files |
| Agreement on nonces/session parameters | `Nisynch` (implies ordered agreement on all exchanged data, including `N1..N4`) | both files |
| Replay-attack resistance | implied by `Nisynch`/`Niagree`: a replayed old message cannot match the fresh nonces of a new run | both files |
| Impersonation resistance | implied by `Nisynch`/`Niagree` + `Weakagree`: the claimed partner must actually exist and have sent the matching messages | both files (`Weakagree` only in the full model) |
| Secrecy of the PUF response/challenge/`theta` | `claim(..., Secret, R)/(C)/(theta)` | `v2x_hardened_full.spdl` only |
| Liveness of the partner role | `Alive` | `v2x_hardened_full.spdl` only |

If you re-verify and see a `Fail`, report it exactly as printed; do not substitute the result
reported here, which reflects the specific model files included in this repository.
