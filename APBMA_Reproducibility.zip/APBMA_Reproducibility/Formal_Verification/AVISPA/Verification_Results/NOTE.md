# AVISPA verification — status

**No AVISPA run has been executed and captured for this repository yet.** The AVISPA Web Tool
and the standalone AVISPA tool distribution could not be installed/run in the environment used
to prepare this package, so no genuine `SAFE` / `UNSAFE` / `INCONCLUSIVE` output exists to
include here. In line with the scientific-integrity requirement for this repository, **no
verification result is fabricated or assumed.**

`v2x_hardened.hlpsl` (in the parent folder) has been syntax-checked by hand (balanced blocks,
`witness`/`request` pairing, and message patterns consistent with the protocol description) but
this is **not** a substitute for an actual OFMC / CL-AtSe run.

## What to do

1. Install AVISPA (see `../AVISPA_Instructions.md`).
2. Run:
   ```bash
   avispa v2x_hardened.hlpsl --ofmc
   avispa v2x_hardened.hlpsl --cl-atse
   ```
3. Save the raw console output of both commands into this folder, e.g. as
   `ofmc_output.txt` and `cl-atse_output.txt`.
4. Fill in the exact paper caption used in this project, replacing the `\fillin{}` placeholders
   with the values you actually observe:

   ```latex
   \small The HLPSL file \texttt{v2x\_hardened.hlpsl} was run with
   \texttt{avispa v2x\_hardened.hlpsl --ofmc} and \texttt{--cl-atse}
   (AVISPA version \fillin{x.y}, \fillin{OS}).\normalsize
   ```

   e.g. once confirmed: `(AVISPA version 1.1, Ubuntu 22.04)` and the SAFE/UNSAFE verdict each
   backend reports — do **not** write "SAFE" in the paper or README unless the tool itself
   printed it.
