# AVISPA Verification Instructions — APBMA

This folder contains the HLPSL model of APBMA's run-time phase (`v2x_hardened.hlpsl`) and
documents how to verify it with AVISPA. **No verification has been run for this repository
yet** — see `Verification_Results/NOTE.md`. The exact version of AVISPA and the operating
system used must be recorded once you run it:

```text
AVISPA version: [fill in after installing/running, e.g. "AVISPA 1.1 (SPAN)"]
Operating system: [fill in, e.g. "Ubuntu 22.04.4 LTS"]
```

The paper reports this run with the following caption (fill in the placeholders only after a
real run):

```latex
\small The HLPSL file \texttt{v2x\_hardened.hlpsl} was run with
\texttt{avispa v2x\_hardened.hlpsl --ofmc} and \texttt{--cl-atse}
(AVISPA version \fillin{x.y}, \fillin{OS}).\normalsize
```

## 1. Install and configure AVISPA

AVISPA is most easily obtained as part of the **SPAN (Security Protocol ANimator for AVISPA)**
virtual machine, which bundles AVISPA with all four of its backends and the correct OCaml/Perl
dependencies pre-built:

1. Download the SPAN VirtualBox image from the AVISPA project page
   (`http://www.avispa-project.org/` → "SPAN tool") or from the SPAN mirror maintained by
   LORIA/INRIA.
2. Import the `.ova`/`.ovf` image into VirtualBox (or VMware) and boot it.
3. Inside the VM, open a terminal; the `avispa` command-line wrapper and the four backends
   (OFMC, CL-AtSe, SATMC, TA4SP) are already on the `PATH`.

If you prefer a native Linux install instead of the VM:

1. Clone the AVISPA tool sources (`git clone https://github.com/avispa-project/avispa` or the
   tarball from the project page).
2. Install the build dependencies it lists (OCaml, a C compiler, `flex`/`bison`, and — for
   CL-AtSe — a recent `gcc`).
3. Build each backend following the `README`/`INSTALL` file in its own subdirectory
   (`OFMC/`, `CL-AtSe/`, `SATMC/`, `TA4SP/`), then build the top-level `avispa` dispatcher that
   calls the HLPSL-to-IF translator (`hlpsl2if`) followed by the chosen backend.
4. Confirm the install with `avispa --help`; record the printed version string.

## 2. Copy the model

Copy `v2x_hardened.hlpsl` into the AVISPA/SPAN working directory (or open it directly from this
path if your install accepts absolute paths).

## 3. Run the OFMC backend

```bash
avispa v2x_hardened.hlpsl --ofmc
```

OFMC performs bounded, on-the-fly model checking. It is the fastest backend and the usual first
check. Typical console output looks like:

```
% OFMC
% Version of 2006/02/13
SUMMARY
  SAFE / UNSAFE / INCONCLUSIVE
DETAILS
  ...
STATISTICS
  ...
```

Save the full console output (copy/paste or redirect with `avispa v2x_hardened.hlpsl --ofmc
2>&1 | tee ofmc_output.txt`) into `Verification_Results/ofmc_output.txt`.

## 4. Run the CL-AtSe backend

```bash
avispa v2x_hardened.hlpsl --cl-atse
```

CL-AtSe (Constraint-Logic-based Attack Searcher) performs a more exhaustive, constraint-based
search and can find attacks OFMC's bound misses, at the cost of more time. Save its output the
same way, as `Verification_Results/cl-atse_output.txt`.

## 5. Interpreting SUMMARY / SAFE / UNSAFE / INCONCLUSIVE

Both backends print a `SUMMARY` section with one of:

- **SAFE** — within the backend's search bound (number of sessions, message depth, etc.), no
  attack trace was found against any of the goals declared in the model's `goal` section.
  This is evidence of, not a mathematical proof of, security: it means no attack exists within
  the explored state space.
- **UNSAFE** — the backend found a concrete attack trace. The `DETAILS` section lists the
  trace (the sequence of intruder actions) step by step; this must be reported verbatim if it
  occurs, not hidden or reframed.
- **INCONCLUSIVE** — the backend could not determine SAFE or UNSAFE within its resource/time
  limits (common for CL-AtSe on larger models, or TA4SP on models with algebraic properties it
  cannot abstract). This is not a pass; report it as inconclusive.

Never report "SAFE" unless the tool itself printed `SAFE` in its `SUMMARY`.

## 6. Security goals and assumptions modeled

Open `v2x_hardened.hlpsl` and locate the `goal` section (and the `secrecy_of` / `authentication_on`
declarations referenced by the roles) to see exactly which properties are declared:

The file's actual `goal` block (lines ~176-184) declares exactly:

```
secrecy_of sec_ks          % session key K_S
secrecy_of sec_r           % PUF response R_V1
secrecy_of sec_c           % PUF challenge C_V1
secrecy_of sec_theta       % theta = beta = h(R_V1)
authentication_on rsu_to_v_n1n2   % V authenticates RSU (M4), with replay protection
authentication_on v_to_rsu_n2n3   % RSU authenticates V (M5), with replay protection
authentication_on rsu_to_v_ks     % key agreement: V and RSU agree on K_S and on N3,N4
```

These are backed by `witness`/`request` pairs in the vehicle and RSU roles (around lines
79-129) that carry the nonces `N1..N4`, so a successful `authentication_on` result also
certifies replay resistance for that exchange — a replayed/old message would carry a stale
nonce value and the `request` side would not match.
- The Dolev-Yao intruder model is assumed throughout (the intruder can intercept, replay,
  reorder, and forge messages from any role it has played, but cannot break the underlying
  cryptographic primitives themselves — this is a standard, explicitly stated AVISPA
  assumption, not something this protocol adds).

Report only the goals that are actually present in the file; do not describe a property as
"verified" if it has no corresponding `goal`/`witness`/`request` declaration in the model.
